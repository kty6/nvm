# TimeWisePro 部署指南

本文档提供了部署TimeWisePro应用的详细步骤和说明。

## 部署方式

TimeWisePro支持两种部署方式：
1. 使用Docker容器化部署（推荐）
2. 手动部署

## 使用Docker部署（推荐）

### 前提条件
- 安装Docker和Docker Compose
- 确保端口5000未被占用

### 部署步骤

1. 克隆或下载项目文件到服务器

2. 进入项目根目录

3. 修改docker-compose.yml中的环境变量（可选）
   ```yaml
   environment:
     - NODE_ENV=production
     - MONGODB_URI=mongodb://mongo:27017/timewisepro
     - JWT_SECRET=your_custom_secret_key  # 建议修改为自定义密钥
   ```

4. 构建并启动容器
   ```bash
   docker-compose up -d
   ```

5. 验证部署
   - 访问 http://your-server-ip:5000
   - 如果一切正常，您应该能看到TimeWisePro的登录页面

### 更新应用

1. 拉取最新代码

2. 重新构建并启动容器
   ```bash
   docker-compose down
   docker-compose up -d --build
   ```

### 备份数据

MongoDB数据存储在名为mongo-data的Docker卷中。要备份数据：

```bash
docker exec -it timewisepro_mongo_1 mongodump --out /data/backup
docker cp timewisepro_mongo_1:/data/backup ./backup
```

## 手动部署

### 前提条件
- Node.js v14+
- MongoDB v4+
- npm或yarn

### 部署步骤

1. 克隆或下载项目文件到服务器

2. 进入项目根目录

3. 安装依赖
   ```bash
   npm install
   ```

4. 创建.env文件并配置环境变量
   ```
   PORT=5000
   MONGODB_URI=mongodb://localhost:27017/timewisepro
   JWT_SECRET=your_custom_secret_key
   NODE_ENV=production
   ```

5. 构建前端
   ```bash
   npm run build
   ```

6. 启动应用
   ```bash
   npm start
   ```
   
   或使用PM2进行进程管理（推荐）
   ```bash
   npm install -g pm2
   pm2 start server/index.js --name timewisepro
   ```

7. 验证部署
   - 访问 http://your-server-ip:5000
   - 如果一切正常，您应该能看到TimeWisePro的登录页面

### 配置Nginx反向代理（可选但推荐）

如果您希望使用域名访问应用或配置HTTPS，可以使用Nginx作为反向代理：

1. 安装Nginx

2. 创建配置文件
   ```
   server {
       listen 80;
       server_name your-domain.com;

       location / {
           proxy_pass http://localhost:5000;
           proxy_http_version 1.1;
           proxy_set_header Upgrade $http_upgrade;
           proxy_set_header Connection 'upgrade';
           proxy_set_header Host $host;
           proxy_cache_bypass $http_upgrade;
       }
   }
   ```

3. 启用配置并重启Nginx

4. 配置SSL（推荐使用Let's Encrypt）

## 故障排除

### 常见问题

1. **无法连接到MongoDB**
   - 检查MongoDB服务是否运行
   - 验证连接字符串是否正确
   - 确认MongoDB端口是否开放

2. **应用启动失败**
   - 检查日志文件查找错误信息
   - 确认所有依赖都已正确安装
   - 验证环境变量是否正确设置

3. **无法访问应用**
   - 确认应用正在运行
   - 检查防火墙设置，确保端口开放
   - 验证服务器IP和端口配置

### 获取帮助

如果您在部署过程中遇到问题，请联系我们的技术支持：

- 邮箱：support@timewisepro.com
- 在线支持：https://timewisepro.com/support
