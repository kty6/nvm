import React, { useState, useEffect, useRef } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { 
  startTimer, 
  pauseTimer, 
  resetTimer, 
  tickTimer, 
  completeSession,
  setWorkDuration,
  setBreakDuration,
  setLongBreakDuration,
  setCurrentTaskId
} from '../../store/slices/pomodoroSlice';
import axios from 'axios';
import TaskSelector from './TaskSelector';

const PomodoroTimer = () => {
  const dispatch = useDispatch();
  const { 
    isActive, 
    workDuration, 
    breakDuration, 
    longBreakDuration,
    currentSession, 
    timeRemaining, 
    completedPomodoros,
    currentTaskId
  } = useSelector(state => state.pomodoro);
  const { tasks } = useSelector(state => state.todo);
  
  const [showSettings, setShowSettings] = useState(false);
  const [workMinutes, setWorkMinutes] = useState(workDuration / 60);
  const [breakMinutes, setBreakMinutes] = useState(breakDuration / 60);
  const [longBreakMinutes, setLongBreakMinutes] = useState(longBreakDuration / 60);
  const [interrupted, setInterrupted] = useState(false);
  const [interruptionReason, setInterruptionReason] = useState('');
  
  const timerRef = useRef(null);
  const audioRef = useRef(null);

  // 初始化音频
  useEffect(() => {
    audioRef.current = new Audio('/notification.mp3');
  }, []);

  // 计时器逻辑
  useEffect(() => {
    if (isActive) {
      timerRef.current = setInterval(() => {
        dispatch(tickTimer());
      }, 1000);
    } else if (timerRef.current) {
      clearInterval(timerRef.current);
    }

    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [isActive, dispatch]);

  // 检查计时器是否结束
  useEffect(() => {
    if (timeRemaining === 0) {
      // 播放通知音效
      if (audioRef.current) {
        audioRef.current.play();
      }
      
      // 记录番茄钟
      if (currentSession === 'work') {
        savePomodoroRecord();
      }
      
      // 完成会话
      dispatch(completeSession());
      dispatch(pauseTimer());
    }
  }, [timeRemaining, currentSession, dispatch]);

  // 保存番茄钟记录到后端
  const savePomodoroRecord = async () => {
    try {
      const token = localStorage.getItem('token');
      const pomodoroData = {
        taskId: currentTaskId,
        startTime: new Date(Date.now() - workDuration * 1000).toISOString(),
        endTime: new Date().toISOString(),
        duration: workDuration / 60, // 转换为分钟
        type: 'work',
        completed: true,
        interrupted: interrupted,
        interruptionReason: interruptionReason
      };
      
      await axios.post('/api/pomodoros', pomodoroData, {
        headers: {
          'x-auth-token': token,
          'Content-Type': 'application/json'
        }
      });
      
      // 重置中断状态
      setInterrupted(false);
      setInterruptionReason('');
    } catch (err) {
      console.error('保存番茄钟记录失败:', err);
    }
  };

  // 处理开始计时
  const handleStart = () => {
    dispatch(startTimer());
  };

  // 处理暂停计时
  const handlePause = () => {
    dispatch(pauseTimer());
  };

  // 处理重置计时
  const handleReset = () => {
    dispatch(resetTimer());
  };

  // 处理中断
  const handleInterrupt = () => {
    setInterrupted(true);
    const reason = prompt('请输入中断原因:');
    if (reason) {
      setInterruptionReason(reason);
    }
    
    // 如果是工作阶段，保存中断的番茄钟记录
    if (currentSession === 'work') {
      const interruptedData = {
        interrupted: true,
        interruptionReason: reason || '用户中断'
      };
      dispatch(completeSession(interruptedData));
    } else {
      dispatch(completeSession());
    }
    
    dispatch(pauseTimer());
    dispatch(resetTimer());
  };

  // 处理跳过当前阶段
  const handleSkip = () => {
    if (currentSession === 'work') {
      const confirmed = window.confirm('确定要跳过当前工作阶段吗？这将不会记录为已完成的番茄钟。');
      if (!confirmed) return;
    }
    
    dispatch(completeSession({ interrupted: true, interruptionReason: '用户跳过' }));
    dispatch(pauseTimer());
    dispatch(resetTimer());
  };

  // 处理设置更新
  const handleSaveSettings = () => {
    dispatch(setWorkDuration(workMinutes));
    dispatch(setBreakDuration(breakMinutes));
    dispatch(setLongBreakDuration(longBreakMinutes));
    setShowSettings(false);
  };

  // 处理任务选择
  const handleTaskSelect = (taskId) => {
    dispatch(setCurrentTaskId(taskId));
  };

  // 格式化时间显示
  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // 获取当前任务
  const currentTask = tasks.find(task => task._id === currentTaskId);

  return (
    <div className="pomodoro-timer">
      <div className="pomodoro-header">
        <h2>番茄钟</h2>
        <button 
          onClick={() => setShowSettings(!showSettings)} 
          className="btn btn-outline-secondary"
        >
          设置
        </button>
      </div>

      <div className="session-info">
        <div className="session-type">
          {currentSession === 'work' ? '工作阶段' : '休息阶段'}
        </div>
        <div className="pomodoro-count">
          已完成番茄钟: {completedPomodoros}
        </div>
      </div>

      <div className="timer-display">
        <div className="time">{formatTime(timeRemaining)}</div>
      </div>

      <div className="task-selection">
        <h4>当前任务</h4>
        <TaskSelector 
          tasks={tasks.filter(task => !task.completed)} 
          selectedTaskId={currentTaskId}
          onSelectTask={handleTaskSelect}
        />
        {currentTask && (
          <div className="current-task-info">
            <div className="task-title">{currentTask.title}</div>
            <div className="task-progress">
              进度: {currentTask.actualPomodoros} / {currentTask.estimatedPomodoros} 番茄钟
            </div>
          </div>
        )}
      </div>

      <div className="timer-controls">
        {!isActive ? (
          <button onClick={handleStart} className="btn btn-primary">
            开始
          </button>
        ) : (
          <button onClick={handlePause} className="btn btn-warning">
            暂停
          </button>
        )}
        <button onClick={handleReset} className="btn btn-secondary">
          重置
        </button>
        <button onClick={handleInterrupt} className="btn btn-danger">
          中断
        </button>
        <button onClick={handleSkip} className="btn btn-info">
          跳过
        </button>
      </div>

      {showSettings && (
        <div className="timer-settings">
          <h4>计时器设置</h4>
          <div className="form-group">
            <label>工作时长 (分钟)</label>
            <input 
              type="number" 
              value={workMinutes} 
              onChange={(e) => setWorkMinutes(parseInt(e.target.value))}
              min="1"
              max="60"
              className="form-control"
            />
          </div>
          <div className="form-group">
            <label>休息时长 (分钟)</label>
            <input 
              type="number" 
              value={breakMinutes} 
              onChange={(e) => setBreakMinutes(parseInt(e.target.value))}
              min="1"
              max="30"
              className="form-control"
            />
          </div>
          <div className="form-group">
            <label>长休息时长 (分钟)</label>
            <input 
              type="number" 
              value={longBreakMinutes} 
              onChange={(e) => setLongBreakMinutes(parseInt(e.target.value))}
              min="1"
              max="60"
              className="form-control"
            />
          </div>
          <button onClick={handleSaveSettings} className="btn btn-primary">
            保存设置
          </button>
          <button onClick={() => setShowSettings(false)} className="btn btn-secondary">
            取消
          </button>
        </div>
      )}
    </div>
  );
};

export default PomodoroTimer;
