import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import axios from 'axios';
import { 
  aiRequestStart, 
  aiRequestSuccess, 
  aiRequestFailure 
} from '../../store/slices/aiSlice';

const AITimeManagement = () => {
  const dispatch = useDispatch();
  const { isConfigured, loading, error, lastResponse } = useSelector(state => state.ai);
  const { schedules } = useSelector(state => state.schedule);
  const { tasks } = useSelector(state => state.todo);
  const [additionalContext, setAdditionalContext] = useState('');
  const [analysisResult, setAnalysisResult] = useState(null);
  const [includeSchedules, setIncludeSchedules] = useState(true);
  const [includeTasks, setIncludeTasks] = useState(true);
  const [includeStatistics, setIncludeStatistics] = useState(true);
  const [timeRange, setTimeRange] = useState('week'); // day, week, month

  // 处理附加上下文变化
  const handleAdditionalContextChange = (e) => {
    setAdditionalContext(e.target.value);
  };

  // 处理时间管理分析请求
  const handleAnalyzeTimeManagement = async () => {
    dispatch(aiRequestStart());
    
    try {
      const token = localStorage.getItem('token');
      
      // 准备数据
      let requestData = {
        additionalContext: additionalContext || undefined
      };
      
      // 根据选择添加日程数据
      if (includeSchedules) {
        // 根据时间范围过滤日程
        const filteredSchedules = filterDataByTimeRange(schedules, timeRange);
        requestData.schedules = filteredSchedules;
      }
      
      // 根据选择添加任务数据
      if (includeTasks) {
        // 根据时间范围过滤任务
        const filteredTasks = filterDataByTimeRange(tasks, timeRange);
        requestData.tasks = filteredTasks;
      }
      
      // 根据选择添加统计数据
      if (includeStatistics) {
        try {
          // 获取统计数据
          const statsRes = await axios.get(`/api/statistics/${timeRange === 'day' ? 'daily' : timeRange === 'week' ? 'weekly' : 'monthly'}/${new Date().toISOString()}`, {
            headers: {
              'x-auth-token': token
            }
          });
          requestData.statistics = statsRes.data;
        } catch (err) {
          console.error('获取统计数据失败:', err);
        }
      }
      
      // 发送请求
      const res = await axios.post('/api/ai/time-management', requestData, {
        headers: {
          'x-auth-token': token,
          'Content-Type': 'application/json'
        }
      });
      
      dispatch(aiRequestSuccess(res.data.result));
      setAnalysisResult(res.data.result);
    } catch (err) {
      dispatch(aiRequestFailure(err.response?.data?.msg || '时间管理分析请求失败'));
    }
  };

  // 根据时间范围过滤数据
  const filterDataByTimeRange = (data, range) => {
    const now = new Date();
    let startDate;
    
    if (range === 'day') {
      startDate = new Date(now.setHours(0, 0, 0, 0));
    } else if (range === 'week') {
      const day = now.getDay() || 7; // 获取星期几，如果是星期天则设为7
      startDate = new Date(now.setDate(now.getDate() - day + 1));
      startDate.setHours(0, 0, 0, 0);
    } else if (range === 'month') {
      startDate = new Date(now.getFullYear(), now.getMonth(), 1);
    }
    
    return data.filter(item => {
      const itemDate = new Date(item.createdAt || item.startTime);
      return itemDate >= startDate;
    });
  };

  return (
    <div className="ai-time-management">
      <h3>AI时间管理分析</h3>
      
      {!isConfigured ? (
        <div className="ai-not-configured">
          <p>您尚未配置AI设置。请先在设置页面配置AI提供商和API密钥。</p>
          <button 
            onClick={() => window.location.href = '/settings'}
            className="btn btn-primary"
          >
            前往设置
          </button>
        </div>
      ) : (
        <div className="time-management-container">
          <div className="analysis-options">
            <h4>分析选项</h4>
            
            <div className="form-group">
              <label>时间范围</label>
              <select
                value={timeRange}
                onChange={(e) => setTimeRange(e.target.value)}
                className="form-control"
              >
                <option value="day">今天</option>
                <option value="week">本周</option>
                <option value="month">本月</option>
              </select>
            </div>
            
            <div className="data-options">
              <div className="form-check">
                <input
                  type="checkbox"
                  id="includeSchedules"
                  checked={includeSchedules}
                  onChange={() => setIncludeSchedules(!includeSchedules)}
                  className="form-check-input"
                />
                <label className="form-check-label" htmlFor="includeSchedules">
                  包含日程数据
                </label>
              </div>
              
              <div className="form-check">
                <input
                  type="checkbox"
                  id="includeTasks"
                  checked={includeTasks}
                  onChange={() => setIncludeTasks(!includeTasks)}
                  className="form-check-input"
                />
                <label className="form-check-label" htmlFor="includeTasks">
                  包含任务数据
                </label>
              </div>
              
              <div className="form-check">
                <input
                  type="checkbox"
                  id="includeStatistics"
                  checked={includeStatistics}
                  onChange={() => setIncludeStatistics(!includeStatistics)}
                  className="form-check-input"
                />
                <label className="form-check-label" htmlFor="includeStatistics">
                  包含统计数据
                </label>
              </div>
            </div>
            
            <div className="form-group">
              <label>附加上下文 (可选)</label>
              <textarea
                value={additionalContext}
                onChange={handleAdditionalContextChange}
                className="form-control"
                rows="3"
                placeholder="输入任何附加信息，如个人目标、工作习惯等"
              />
            </div>
            
            <button 
              onClick={handleAnalyzeTimeManagement}
              className="btn btn-primary"
              disabled={loading || (!includeSchedules && !includeTasks && !includeStatistics)}
            >
              {loading ? '分析中...' : '分析时间管理'}
            </button>
          </div>
          
          {error && <div className="alert alert-danger">{error}</div>}
          
          {analysisResult && (
            <div className="analysis-result-section">
              <h4>AI分析结果</h4>
              
              <div className="result-content">
                {analysisResult.split('\n').map((line, index) => (
                  <p key={index}>{line}</p>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default AITimeManagement;
