import React from 'react';
import { useDispatch } from 'react-redux';
import { deleteSchedule } from '../../store/slices/scheduleSlice';
import axios from 'axios';
import moment from 'moment';

const ScheduleDetail = ({ schedule, onEdit, onClose }) => {
  const dispatch = useDispatch();

  // 处理删除日程
  const handleDelete = async () => {
    if (window.confirm('确定要删除此日程吗？')) {
      try {
        const token = localStorage.getItem('token');
        await axios.delete(`/api/schedules/${schedule._id}`, {
          headers: {
            'x-auth-token': token
          }
        });
        dispatch(deleteSchedule(schedule._id));
        onClose();
      } catch (err) {
        console.error('删除日程失败:', err);
      }
    }
  };

  // 格式化日期显示
  const formatDateTime = (dateTime, isAllDay = false) => {
    if (isAllDay) {
      return moment(dateTime).format('YYYY-MM-DD');
    }
    return moment(dateTime).format('YYYY-MM-DD HH:mm');
  };

  // 获取重复类型的中文描述
  const getRecurrenceTypeText = (type) => {
    const types = {
      none: '不重复',
      daily: '每天',
      weekly: '每周',
      monthly: '每月',
      yearly: '每年'
    };
    return types[type] || '不重复';
  };

  // 获取优先级的中文描述
  const getPriorityText = (priority) => {
    const priorities = {
      1: '很低',
      2: '低',
      3: '中',
      4: '高',
      5: '很高'
    };
    return priorities[priority] || '中';
  };

  return (
    <div className="schedule-detail-modal">
      <div className="modal-content">
        <div className="modal-header">
          <h3>日程详情</h3>
          <button onClick={onClose} className="close-btn">&times;</button>
        </div>
        
        <div className="schedule-detail-content">
          <h4 className="schedule-title">{schedule.title}</h4>
          
          <div className="schedule-time">
            <div className="time-label">时间：</div>
            <div className="time-value">
              {formatDateTime(schedule.startTime, schedule.isAllDay)} 至 {formatDateTime(schedule.endTime, schedule.isAllDay)}
              {schedule.isAllDay && ' (全天)'}
            </div>
          </div>
          
          {schedule.location && (
            <div className="schedule-location">
              <div className="location-label">地点：</div>
              <div className="location-value">{schedule.location}</div>
            </div>
          )}
          
          {schedule.description && (
            <div className="schedule-description">
              <div className="description-label">描述：</div>
              <div className="description-value">{schedule.description}</div>
            </div>
          )}
          
          <div className="schedule-recurrence">
            <div className="recurrence-label">重复：</div>
            <div className="recurrence-value">
              {getRecurrenceTypeText(schedule.recurrence.type)}
              {schedule.recurrence.type !== 'none' && (
                <>
                  {schedule.recurrence.interval > 1 && `，间隔 ${schedule.recurrence.interval} 个单位`}
                  {schedule.recurrence.endDate && `，截止至 ${formatDateTime(schedule.recurrence.endDate, true)}`}
                </>
              )}
            </div>
          </div>
          
          <div className="schedule-reminder">
            <div className="reminder-label">提醒：</div>
            <div className="reminder-value">
              {schedule.reminder.enabled ? `提前 ${schedule.reminder.time} 分钟` : '不提醒'}
            </div>
          </div>
          
          <div className="schedule-category">
            <div className="category-label">类别：</div>
            <div className="category-value">{schedule.category}</div>
          </div>
          
          {schedule.tags && schedule.tags.length > 0 && (
            <div className="schedule-tags">
              <div className="tags-label">标签：</div>
              <div className="tags-value">
                {schedule.tags.map(tag => (
                  <span key={tag} className="badge bg-primary me-1">{tag}</span>
                ))}
              </div>
            </div>
          )}
          
          <div className="schedule-priority">
            <div className="priority-label">优先级：</div>
            <div className="priority-value">{getPriorityText(schedule.priority)}</div>
          </div>
        </div>
        
        <div className="modal-footer">
          <button onClick={handleDelete} className="btn btn-danger">
            删除
          </button>
          <button onClick={onEdit} className="btn btn-primary">
            编辑
          </button>
        </div>
      </div>
    </div>
  );
};

export default ScheduleDetail;
