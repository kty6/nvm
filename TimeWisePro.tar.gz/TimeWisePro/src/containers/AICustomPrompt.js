import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import axios from 'axios';
import { 
  aiRequestStart, 
  aiRequestSuccess, 
  aiRequestFailure 
} from '../../store/slices/aiSlice';

const AICustomPrompt = () => {
  const dispatch = useDispatch();
  const { isConfigured, loading, error, customPrompts } = useSelector(state => state.ai);
  const [promptType, setPromptType] = useState('custom');
  const [customPromptText, setCustomPromptText] = useState('');
  const [promptResult, setPromptResult] = useState(null);

  // 处理提示词类型变化
  const handlePromptTypeChange = (e) => {
    setPromptType(e.target.value);
    setCustomPromptText('');
  };

  // 处理自定义提示词变化
  const handleCustomPromptChange = (e) => {
    setCustomPromptText(e.target.value);
  };

  // 处理选择预设提示词
  const handleSelectPresetPrompt = (promptName) => {
    if (customPrompts[promptName]) {
      setCustomPromptText(customPrompts[promptName]);
    }
  };

  // 处理发送提示词请求
  const handleSendPrompt = async () => {
    if (!customPromptText.trim()) {
      alert('请输入提示词');
      return;
    }

    dispatch(aiRequestStart());
    
    try {
      const token = localStorage.getItem('token');
      const promptData = {
        prompt: customPromptText
      };
      
      const res = await axios.post('/api/ai/custom-prompt', promptData, {
        headers: {
          'x-auth-token': token,
          'Content-Type': 'application/json'
        }
      });
      
      dispatch(aiRequestSuccess(res.data.result));
      setPromptResult(res.data.result);
    } catch (err) {
      dispatch(aiRequestFailure(err.response?.data?.msg || '提示词请求失败'));
    }
  };

  return (
    <div className="ai-custom-prompt">
      <h3>自定义AI提示词</h3>
      
      {!isConfigured ? (
        <div className="ai-not-configured">
          <p>您尚未配置AI设置。请先在设置页面配置AI提供商和API密钥。</p>
          <button 
            onClick={() => window.location.href = '/settings'}
            className="btn btn-primary"
          >
            前往设置
          </button>
        </div>
      ) : (
        <div className="custom-prompt-container">
          <div className="prompt-input-section">
            <div className="form-group">
              <label>提示词类型</label>
              <select
                value={promptType}
                onChange={handlePromptTypeChange}
                className="form-control"
              >
                <option value="custom">自定义提示词</option>
                {Object.keys(customPrompts).length > 0 && (
                  <option value="preset">预设提示词</option>
                )}
              </select>
            </div>
            
            {promptType === 'preset' && Object.keys(customPrompts).length > 0 && (
              <div className="preset-prompts">
                <label>选择预设提示词</label>
                <div className="preset-prompts-list">
                  {Object.keys(customPrompts).map(promptName => (
                    <button
                      key={promptName}
                      onClick={() => handleSelectPresetPrompt(promptName)}
                      className="btn btn-outline-secondary me-2 mb-2"
                    >
                      {promptName}
                    </button>
                  ))}
                </div>
              </div>
            )}
            
            <div className="form-group">
              <label>提示词内容</label>
              <textarea
                value={customPromptText}
                onChange={handleCustomPromptChange}
                className="form-control"
                rows="5"
                placeholder="输入您的提示词..."
              />
            </div>
            
            <button 
              onClick={handleSendPrompt}
              className="btn btn-primary"
              disabled={loading || !customPromptText.trim()}
            >
              {loading ? '处理中...' : '发送提示词'}
            </button>
          </div>
          
          {error && <div className="alert alert-danger">{error}</div>}
          
          {promptResult && (
            <div className="prompt-result-section">
              <h4>AI响应结果</h4>
              
              <div className="result-content">
                {promptResult.split('\n').map((line, index) => (
                  <p key={index}>{line}</p>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default AICustomPrompt;
