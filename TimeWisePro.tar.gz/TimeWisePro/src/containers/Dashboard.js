import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import { Link } from 'react-router-dom';

const Dashboard = () => {
  const { schedules } = useSelector(state => state.schedule);
  const { tasks } = useSelector(state => state.todo);
  const { completedPomodoros } = useSelector(state => state.pomodoro);
  
  const [upcomingSchedules, setUpcomingSchedules] = useState([]);
  const [pendingTasks, setPendingTasks] = useState([]);
  const [todayStats, setTodayStats] = useState({
    completedTasks: 0,
    totalTasks: 0,
    completedPomodoros: 0
  });
  
  // 获取今日日期
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  // 获取明天日期
  const tomorrow = new Date(today);
  tomorrow.setDate(tomorrow.getDate() + 1);
  
  // 获取一周后日期
  const nextWeek = new Date(today);
  nextWeek.setDate(nextWeek.getDate() + 7);

  // 处理即将到来的日程
  useEffect(() => {
    if (schedules.length > 0) {
      const upcoming = schedules
        .filter(schedule => {
          const scheduleDate = new Date(schedule.startTime);
          return scheduleDate >= today && scheduleDate < nextWeek;
        })
        .sort((a, b) => new Date(a.startTime) - new Date(b.startTime))
        .slice(0, 5);
      
      setUpcomingSchedules(upcoming);
    }
  }, [schedules]);

  // 处理待处理任务
  useEffect(() => {
    if (tasks.length > 0) {
      const pending = tasks
        .filter(task => !task.completed)
        .sort((a, b) => {
          // 先按截止日期排序
          if (a.dueDate && b.dueDate) {
            return new Date(a.dueDate) - new Date(b.dueDate);
          }
          if (a.dueDate) return -1;
          if (b.dueDate) return 1;
          
          // 然后按优先级排序
          return b.priority - a.priority;
        })
        .slice(0, 5);
      
      setPendingTasks(pending);
      
      // 计算今日任务统计
      const todayTasks = tasks.filter(task => {
        if (task.createdAt) {
          const taskDate = new Date(task.createdAt);
          return taskDate >= today && taskDate < tomorrow;
        }
        return false;
      });
      
      const completedTodayTasks = todayTasks.filter(task => task.completed);
      
      setTodayStats(prev => ({
        ...prev,
        completedTasks: completedTodayTasks.length,
        totalTasks: todayTasks.length
      }));
    }
  }, [tasks]);

  // 处理今日番茄钟统计
  useEffect(() => {
    setTodayStats(prev => ({
      ...prev,
      completedPomodoros
    }));
  }, [completedPomodoros]);

  // 格式化日期显示
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('zh-CN', { 
      month: 'short', 
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // 获取优先级标签
  const getPriorityLabel = (priority) => {
    switch (priority) {
      case 5: return '很高';
      case 4: return '高';
      case 3: return '中';
      case 2: return '低';
      case 1: return '很低';
      default: return '中';
    }
  };

  // 获取优先级类名
  const getPriorityClass = (priority) => {
    switch (priority) {
      case 5: return 'text-danger';
      case 4: return 'text-warning';
      case 3: return 'text-info';
      case 2: return 'text-success';
      case 1: return 'text-gray';
      default: return 'text-info';
    }
  };

  return (
    <div className="dashboard-container">
      <h2 className="mb-4">仪表盘</h2>
      
      <div className="dashboard">
        {/* 今日统计卡片 */}
        <div className="dashboard-card">
          <div className="dashboard-card-header">
            <h3 className="dashboard-card-title">今日概览</h3>
          </div>
          <div className="dashboard-card-body">
            <div className="stats-item">
              <div className="stats-label">任务完成率</div>
              <div className="stats-value">
                {todayStats.totalTasks > 0 
                  ? `${Math.round((todayStats.completedTasks / todayStats.totalTasks) * 100)}%` 
                  : '0%'}
                <span className="stats-detail">
                  ({todayStats.completedTasks}/{todayStats.totalTasks})
                </span>
              </div>
            </div>
            
            <div className="stats-item">
              <div className="stats-label">完成番茄钟</div>
              <div className="stats-value">{todayStats.completedPomodoros}</div>
            </div>
            
            <div className="progress-container">
              <div className="progress-label">今日进度</div>
              <div className="progress">
                <div 
                  className="progress-bar" 
                  style={{ 
                    width: `${todayStats.totalTasks > 0 
                      ? Math.round((todayStats.completedTasks / todayStats.totalTasks) * 100) 
                      : 0}%` 
                  }}
                ></div>
              </div>
            </div>
          </div>
          <div className="dashboard-card-footer">
            <Link to="/statistics" className="btn btn-sm btn-outline-primary">查看详细统计</Link>
          </div>
        </div>
        
        {/* 待处理任务卡片 */}
        <div className="dashboard-card">
          <div className="dashboard-card-header">
            <h3 className="dashboard-card-title">待处理任务</h3>
          </div>
          <div className="dashboard-card-body">
            {pendingTasks.length > 0 ? (
              <ul className="dashboard-list">
                {pendingTasks.map(task => (
                  <li key={task._id} className="dashboard-list-item">
                    <div className="item-main">
                      <div className="item-title">{task.title}</div>
                      <div className="item-meta">
                        <span className={`priority-badge ${getPriorityClass(task.priority)}`}>
                          {getPriorityLabel(task.priority)}
                        </span>
                        {task.dueDate && (
                          <span className="due-date">
                            截止: {new Date(task.dueDate).toLocaleDateString()}
                          </span>
                        )}
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            ) : (
              <div className="empty-state">暂无待处理任务</div>
            )}
          </div>
          <div className="dashboard-card-footer">
            <Link to="/todo" className="btn btn-sm btn-outline-primary">查看所有任务</Link>
          </div>
        </div>
        
        {/* 即将到来的日程卡片 */}
        <div className="dashboard-card">
          <div className="dashboard-card-header">
            <h3 className="dashboard-card-title">即将到来的日程</h3>
          </div>
          <div className="dashboard-card-body">
            {upcomingSchedules.length > 0 ? (
              <ul className="dashboard-list">
                {upcomingSchedules.map(schedule => (
                  <li key={schedule._id} className="dashboard-list-item">
                    <div className="item-main">
                      <div className="item-title">{schedule.title}</div>
                      <div className="item-meta">
                        <span className="schedule-time">
                          {formatDate(schedule.startTime)}
                        </span>
                        {schedule.location && (
                          <span className="location">
                            @ {schedule.location}
                          </span>
                        )}
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            ) : (
              <div className="empty-state">暂无即将到来的日程</div>
            )}
          </div>
          <div className="dashboard-card-footer">
            <Link to="/schedule" className="btn btn-sm btn-outline-primary">查看所有日程</Link>
          </div>
        </div>
        
        {/* 快速操作卡片 */}
        <div className="dashboard-card">
          <div className="dashboard-card-header">
            <h3 className="dashboard-card-title">快速操作</h3>
          </div>
          <div className="dashboard-card-body">
            <div className="quick-actions">
              <Link to="/todo" className="quick-action-btn">
                <i className="fas fa-plus-circle"></i>
                <span>新建任务</span>
              </Link>
              
              <Link to="/schedule" className="quick-action-btn">
                <i className="fas fa-calendar-plus"></i>
                <span>添加日程</span>
              </Link>
              
              <Link to="/pomodoro" className="quick-action-btn">
                <i className="fas fa-play-circle"></i>
                <span>开始番茄钟</span>
              </Link>
              
              <Link to="/ai/task-breakdown" className="quick-action-btn">
                <i className="fas fa-project-diagram"></i>
                <span>AI任务拆分</span>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
