import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import axios from 'axios';
import { 
  Chart as ChartJS, 
  CategoryScale, 
  LinearScale, 
  BarElement, 
  Title, 
  Tooltip, 
  Legend,
  ArcElement,
  PointElement,
  LineElement,
  RadialLinearScale,
  Filler
} from 'chart.js';
import { Bar, Pie, Line, Radar } from 'react-chartjs-2';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';

// 注册ChartJS组件
ChartJS.register(
  CategoryScale, 
  LinearScale, 
  BarElement, 
  Title, 
  Tooltip, 
  Legend,
  ArcElement,
  PointElement,
  LineElement,
  RadialLinearScale,
  Filler
);

const Statistics = () => {
  const [viewType, setViewType] = useState('daily'); // daily, weekly, monthly
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [startDate, setStartDate] = useState(new Date());
  const [statistics, setStatistics] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [categoryStats, setCategoryStats] = useState([]);

  // 获取统计数据
  useEffect(() => {
    const fetchStatistics = async () => {
      setLoading(true);
      setError(null);
      
      try {
        const token = localStorage.getItem('token');
        let url;
        
        if (viewType === 'daily') {
          url = `/api/statistics/daily/${selectedDate.toISOString()}`;
        } else if (viewType === 'weekly') {
          url = `/api/statistics/weekly/${startDate.toISOString()}`;
        } else if (viewType === 'monthly') {
          const year = selectedDate.getFullYear();
          const month = selectedDate.getMonth() + 1;
          url = `/api/statistics/monthly/${year}/${month}`;
        }
        
        const res = await axios.get(url, {
          headers: {
            'x-auth-token': token
          }
        });
        
        setStatistics(res.data);
      } catch (err) {
        setError(err.response?.data?.msg || '获取统计数据失败');
      } finally {
        setLoading(false);
      }
    };

    fetchStatistics();
  }, [viewType, selectedDate, startDate]);

  // 获取类别统计数据
  useEffect(() => {
    const fetchCategoryStats = async () => {
      try {
        const token = localStorage.getItem('token');
        const res = await axios.get('/api/statistics/categories', {
          headers: {
            'x-auth-token': token
          }
        });
        
        setCategoryStats(res.data);
      } catch (err) {
        console.error('获取类别统计失败:', err);
      }
    };

    fetchCategoryStats();
  }, []);

  // 处理视图类型变化
  const handleViewTypeChange = (type) => {
    setViewType(type);
    
    // 如果切换到周视图，设置开始日期为本周一
    if (type === 'weekly') {
      const monday = new Date();
      monday.setDate(monday.getDate() - monday.getDay() + 1);
      setStartDate(monday);
    }
  };

  // 准备日视图数据
  const prepareDailyData = () => {
    if (!statistics) return null;
    
    // 番茄钟分布数据
    const pomodoroData = {
      labels: ['已完成', '未完成'],
      datasets: [
        {
          label: '番茄钟',
          data: [statistics.completedPomodoros, statistics.totalPomodoros - statistics.completedPomodoros],
          backgroundColor: ['rgba(75, 192, 192, 0.6)', 'rgba(255, 99, 132, 0.6)'],
          borderColor: ['rgba(75, 192, 192, 1)', 'rgba(255, 99, 132, 1)'],
          borderWidth: 1,
        },
      ],
    };
    
    // 任务完成情况数据
    const taskData = {
      labels: ['已完成', '未完成'],
      datasets: [
        {
          label: '任务',
          data: [statistics.completedTasks, statistics.totalTasks - statistics.completedTasks],
          backgroundColor: ['rgba(54, 162, 235, 0.6)', 'rgba(255, 206, 86, 0.6)'],
          borderColor: ['rgba(54, 162, 235, 1)', 'rgba(255, 206, 86, 1)'],
          borderWidth: 1,
        },
      ],
    };
    
    // 类别时间分布数据
    const categoryLabels = statistics.categories.map(cat => cat.name);
    const categoryData = statistics.categories.map(cat => cat.timeSpent);
    
    const categoryTimeData = {
      labels: categoryLabels,
      datasets: [
        {
          label: '时间分配（分钟）',
          data: categoryData,
          backgroundColor: 'rgba(153, 102, 255, 0.6)',
          borderColor: 'rgba(153, 102, 255, 1)',
          borderWidth: 1,
        },
      ],
    };
    
    return {
      pomodoroData,
      taskData,
      categoryTimeData,
      productivityScore: statistics.productivityScore
    };
  };

  // 准备周视图数据
  const prepareWeeklyData = () => {
    if (!statistics || !statistics.days) return null;
    
    const days = ['周一', '周二', '周三', '周四', '周五', '周六', '周日'];
    const pomodoroData = statistics.days.map(day => day.completedPomodoros);
    const taskData = statistics.days.map(day => day.completedTasks);
    const productivityData = statistics.days.map(day => day.productivityScore);
    
    // 每日番茄钟和任务完成情况
    const dailyActivityData = {
      labels: days,
      datasets: [
        {
          label: '完成的番茄钟',
          data: pomodoroData,
          backgroundColor: 'rgba(75, 192, 192, 0.6)',
          borderColor: 'rgba(75, 192, 192, 1)',
          borderWidth: 1,
        },
        {
          label: '完成的任务',
          data: taskData,
          backgroundColor: 'rgba(54, 162, 235, 0.6)',
          borderColor: 'rgba(54, 162, 235, 1)',
          borderWidth: 1,
        },
      ],
    };
    
    // 生产力得分趋势
    const productivityTrendData = {
      labels: days,
      datasets: [
        {
          label: '生产力得分',
          data: productivityData,
          fill: false,
          backgroundColor: 'rgba(255, 99, 132, 0.6)',
          borderColor: 'rgba(255, 99, 132, 1)',
          tension: 0.1,
        },
      ],
    };
    
    return {
      dailyActivityData,
      productivityTrendData,
      totalCompletedTasks: statistics.totalCompletedTasks,
      totalTasks: statistics.totalTasks,
      totalCompletedPomodoros: statistics.totalCompletedPomodoros,
      totalWorkTime: statistics.totalWorkTime,
      averageProductivityScore: statistics.averageProductivityScore
    };
  };

  // 准备月视图数据
  const prepareMonthlyData = () => {
    if (!statistics || !statistics.days) return null;
    
    // 获取当月天数
    const daysInMonth = new Date(selectedDate.getFullYear(), selectedDate.getMonth() + 1, 0).getDate();
    const dayLabels = Array.from({ length: daysInMonth }, (_, i) => i + 1);
    
    // 初始化数据数组
    const pomodoroData = Array(daysInMonth).fill(0);
    const taskData = Array(daysInMonth).fill(0);
    const productivityData = Array(daysInMonth).fill(0);
    
    // 填充实际数据
    statistics.days.forEach(day => {
      const dayOfMonth = new Date(day.date).getDate() - 1;
      pomodoroData[dayOfMonth] = day.completedPomodoros;
      taskData[dayOfMonth] = day.completedTasks;
      productivityData[dayOfMonth] = day.productivityScore;
    });
    
    // 月度活动数据
    const monthlyActivityData = {
      labels: dayLabels,
      datasets: [
        {
          label: '完成的番茄钟',
          data: pomodoroData,
          backgroundColor: 'rgba(75, 192, 192, 0.6)',
          borderColor: 'rgba(75, 192, 192, 1)',
          borderWidth: 1,
          type: 'bar',
        },
        {
          label: '生产力得分',
          data: productivityData,
          fill: false,
          backgroundColor: 'rgba(255, 99, 132, 0.6)',
          borderColor: 'rgba(255, 99, 132, 1)',
          tension: 0.1,
          type: 'line',
          yAxisID: 'y1',
        },
      ],
    };
    
    // 任务完成趋势
    const taskTrendData = {
      labels: dayLabels,
      datasets: [
        {
          label: '完成的任务',
          data: taskData,
          fill: true,
          backgroundColor: 'rgba(54, 162, 235, 0.2)',
          borderColor: 'rgba(54, 162, 235, 1)',
          tension: 0.1,
        },
      ],
    };
    
    return {
      monthlyActivityData,
      taskTrendData,
      totalCompletedTasks: statistics.totalCompletedTasks,
      totalTasks: statistics.totalTasks,
      totalCompletedPomodoros: statistics.totalCompletedPomodoros,
      totalWorkTime: statistics.totalWorkTime,
      averageProductivityScore: statistics.averageProductivityScore
    };
  };

  // 准备类别统计数据
  const prepareCategoryData = () => {
    if (!categoryStats || categoryStats.length === 0) return null;
    
    const labels = categoryStats.map(cat => cat.name);
    const data = categoryStats.map(cat => cat.timeSpent);
    
    const categoryData = {
      labels,
      datasets: [
        {
          label: '总时间分配（分钟）',
          data,
          backgroundColor: [
            'rgba(255, 99, 132, 0.6)',
            'rgba(54, 162, 235, 0.6)',
            'rgba(255, 206, 86, 0.6)',
            'rgba(75, 192, 192, 0.6)',
            'rgba(153, 102, 255, 0.6)',
            'rgba(255, 159, 64, 0.6)',
            'rgba(199, 199, 199, 0.6)',
          ],
          borderColor: [
            'rgba(255, 99, 132, 1)',
            'rgba(54, 162, 235, 1)',
            'rgba(255, 206, 86, 1)',
            'rgba(75, 192, 192, 1)',
            'rgba(153, 102, 255, 1)',
            'rgba(255, 159, 64, 1)',
            'rgba(199, 199, 199, 1)',
          ],
          borderWidth: 1,
        },
      ],
    };
    
    return categoryData;
  };

  // 渲染日视图
  const renderDailyView = () => {
    const data = prepareDailyData();
    if (!data) return <div className="loading">加载中...</div>;
    
    return (
      <div className="daily-statistics">
        <div className="date-selector">
          <DatePicker
            selected={selectedDate}
            onChange={date => setSelectedDate(date)}
            dateFormat="yyyy-MM-dd"
            className="form-control"
          />
        </div>
        
        <div className="productivity-score">
          <h3>今日生产力得分</h3>
          <div className="score-display">
            <div className="score-value">{Math.round(data.productivityScore)}</div>
            <div className="score-max">/100</div>
          </div>
        </div>
        
        <div className="statistics-row">
          <div className="statistics-card">
            <h4>番茄钟完成情况</h4>
            <div className="chart-container">
              <Pie data={data.pomodoroData} />
            </div>
          </div>
          
          <div className="statistics-card">
            <h4>任务完成情况</h4>
            <div className="chart-container">
              <Pie data={data.taskData} />
            </div>
          </div>
        </div>
        
        <div className="statistics-card full-width">
          <h4>类别时间分布</h4>
          <div className="chart-container">
            <Bar data={data.categoryTimeData} />
          </div>
        </div>
      </div>
    );
  };

  // 渲染周视图
  const renderWeeklyView = () => {
    const data = prepareWeeklyData();
    if (!data) return <div className="loading">加载中...</div>;
    
    return (
      <div className="weekly-statistics">
        <div className="date-selector">
          <DatePicker
            selected={startDate}
            onChange={date => setStartDate(date)}
            dateFormat="yyyy-MM-dd"
            className="form-control"
          />
          <span className="date-range">
            至 {new Date(startDate.getTime() + 6 * 24 * 60 * 60 * 1000).toLocaleDateString()}
          </span>
        </div>
        
        <div className="summary-cards">
          <div className="summary-card">
            <h4>完成任务</h4>
            <div className="summary-value">{data.totalCompletedTasks}/{data.totalTasks}</div>
          </div>
          
          <div className="summary-card">
            <h4>完成番茄钟</h4>
            <div className="summary-value">{data.totalCompletedPomodoros}</div>
          </div>
          
          <div className="summary-card">
            <h4>工作时间</h4>
            <div className="summary-value">{Math.round(data.totalWorkTime / 60)} 小时</div>
          </div>
          
          <div className="summary-card">
            <h4>平均生产力</h4>
            <div className="summary-value">{Math.round(data.averageProductivityScore)}/100</div>
          </div>
        </div>
        
        <div className="statistics-card full-width">
          <h4>每日活动</h4>
          <div className="chart-container">
            <Bar data={data.dailyActivityData} />
          </div>
        </div>
        
        <div className="statistics-card full-width">
          <h4>生产力趋势</h4>
          <div className="chart-container">
            <Line data={data.productivityTrendData} />
          </div>
        </div>
      </div>
    );
  };

  // 渲染月视图
  const renderMonthlyView = () => {
    const data = prepareMonthlyData();
    if (!data) return <div className="loading">加载中...</div>;
    
    return (
      <div className="monthly-statistics">
        <div className="date-selector">
          <DatePicker
            selected={selectedDate}
            onChange={date => setSelectedDate(date)}
            dateFormat="yyyy-MM"
            showMonthYearPicker
            className="form-control"
          />
        </div>
        
        <div className="summary-cards">
          <div className="summary-card">
            <h4>完成任务</h4>
            <div className="summary-value">{data.totalCompletedTasks}/{data.totalTasks}</div>
          </div>
          
          <div className="summary-card">
            <h4>完成番茄钟</h4>
            <div className="summary-value">{data.totalCompletedPomodoros}</div>
          </div>
          
          <div className="summary-card">
            <h4>工作时间</h4>
            <div className="summary-value">{Math.round(data.totalWorkTime / 60)} 小时</div>
          </div>
          
          <div className="summary-card">
            <h4>平均生产力</h4>
            <div className="summary-value">{Math.round(data.averageProductivityScore)}/100</div>
          </div>
        </div>
        
        <div className="statistics-card full-width">
          <h4>月度活动</h4>
          <div className="chart-container">
            <Bar data={data.monthlyActivityData} options={{
              scales: {
                y: {
                  type: 'linear',
                  display: true,
                  position: 'left',
                },
                y1: {
                  type: 'linear',
                  display: true,
                  position: 'right',
                  min: 0,
                  max: 100,
                  grid: {
                    drawOnChartArea: false,
                  },
                },
              }
            }} />
          </div>
        </div>
        
        <div className="statistics-card full-width">
          <h4>任务完成趋势</h4>
          <div className="chart-container">
            <Line data={data.taskTrendData} />
          </div>
        </div>
      </div>
    );
  };

  // 渲染类别统计
  const renderCategoryStats = () => {
    const data = prepareCategoryData();
    if (!data) return <div className="loading">加载中...</div>;
    
    return (
      <div className="category-statistics">
        <h3>类别时间分布</h3>
        <div className="chart-container">
          <Pie data={data} />
        </div>
      </div>
    );
  };

  return (
    <div className="statistics-container">
      <div className="statistics-header">
        <h2>时间管理统计</h2>
        <div className="view-selector">
          <button 
            className={`btn ${viewType === 'daily' ? 'btn-primary' : 'btn-outline-primary'}`}
            onClick={() => handleViewTypeChange('daily')}
          >
            日视图
          </button>
          <button 
            className={`btn ${viewType === 'weekly' ? 'btn-primary' : 'btn-outline-primary'}`}
            onClick={() => handleViewTypeChange('weekly')}
          >
            周视图
          </button>
          <button 
            className={`btn ${viewType === 'monthly' ? 'btn-primary' : 'btn-outline-primary'}`}
            onClick={() => handleViewTypeChange('monthly')}
          >
            月视图
          </button>
        </div>
      </div>

      {loading ? (
        <div className="loading">加载中...</div>
      ) : error ? (
        <div className="error">{error}</div>
      ) : (
        <div className="statistics-content">
          {viewType === 'daily' && renderDailyView()}
          {viewType === 'weekly' && renderWeeklyView()}
          {viewType === 'monthly' && renderMonthlyView()}
          
          <div className="statistics-divider"></div>
          
          {renderCategoryStats()}
        </div>
      )}
    </div>
  );
};

export default Statistics;
