import React from 'react';
import { useDispatch } from 'react-redux';
import { deleteTask } from '../../store/slices/todoSlice';
import axios from 'axios';
import moment from 'moment';

const TaskDetail = ({ task, onEdit, onClose, onToggleComplete }) => {
  const dispatch = useDispatch();

  // 处理删除任务
  const handleDelete = async () => {
    if (window.confirm('确定要删除此任务吗？')) {
      try {
        const token = localStorage.getItem('token');
        await axios.delete(`/api/tasks/${task._id}`, {
          headers: {
            'x-auth-token': token
          }
        });
        dispatch(deleteTask(task._id));
        onClose();
      } catch (err) {
        console.error('删除任务失败:', err);
      }
    }
  };

  // 格式化日期显示
  const formatDate = (date) => {
    if (!date) return '无截止日期';
    return moment(date).format('YYYY-MM-DD');
  };

  // 获取优先级的中文描述
  const getPriorityText = (priority) => {
    const priorities = {
      1: '很低',
      2: '低',
      3: '中',
      4: '高',
      5: '很高'
    };
    return priorities[priority] || '中';
  };

  return (
    <div className="task-detail-modal">
      <div className="modal-content">
        <div className="modal-header">
          <h3>任务详情</h3>
          <button onClick={onClose} className="close-btn">&times;</button>
        </div>
        
        <div className="task-detail-content">
          <div className="task-header">
            <h4 className="task-title">{task.title}</h4>
            <div className="task-status">
              <span className={`status-badge ${task.completed ? 'completed' : 'active'}`}>
                {task.completed ? '已完成' : '进行中'}
              </span>
            </div>
          </div>
          
          {task.description && (
            <div className="task-description">
              <div className="description-label">描述：</div>
              <div className="description-value">{task.description}</div>
            </div>
          )}
          
          <div className="task-due-date">
            <div className="due-date-label">截止日期：</div>
            <div className="due-date-value">{formatDate(task.dueDate)}</div>
          </div>
          
          {task.completed && task.completedAt && (
            <div className="task-completed-at">
              <div className="completed-at-label">完成时间：</div>
              <div className="completed-at-value">{moment(task.completedAt).format('YYYY-MM-DD HH:mm')}</div>
            </div>
          )}
          
          <div className="task-category">
            <div className="category-label">类别：</div>
            <div className="category-value">{task.category}</div>
          </div>
          
          {task.tags && task.tags.length > 0 && (
            <div className="task-tags">
              <div className="tags-label">标签：</div>
              <div className="tags-value">
                {task.tags.map(tag => (
                  <span key={tag} className="badge bg-primary me-1">{tag}</span>
                ))}
              </div>
            </div>
          )}
          
          <div className="task-priority">
            <div className="priority-label">优先级：</div>
            <div className="priority-value">{getPriorityText(task.priority)}</div>
          </div>
          
          <div className="task-pomodoros">
            <div className="pomodoros-label">番茄钟：</div>
            <div className="pomodoros-value">
              已完成 {task.actualPomodoros} / 预计 {task.estimatedPomodoros}
            </div>
          </div>
        </div>
        
        <div className="modal-footer">
          <button onClick={handleDelete} className="btn btn-danger">
            删除
          </button>
          <button onClick={onToggleComplete} className="btn btn-success">
            {task.completed ? '标记为未完成' : '标记为已完成'}
          </button>
          <button onClick={onEdit} className="btn btn-primary">
            编辑
          </button>
        </div>
      </div>
    </div>
  );
};

export default TaskDetail;
