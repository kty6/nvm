import React from 'react';
import { useSelector } from 'react-redux';

const TaskItem = ({ task, onSelect, onToggleComplete }) => {
  // 获取优先级的样式类
  const getPriorityClass = (priority) => {
    const classes = {
      1: 'priority-very-low',
      2: 'priority-low',
      3: 'priority-medium',
      4: 'priority-high',
      5: 'priority-very-high'
    };
    return classes[priority] || 'priority-medium';
  };

  // 格式化日期显示
  const formatDate = (date) => {
    if (!date) return '';
    const taskDate = new Date(date);
    return taskDate.toLocaleDateString('zh-CN');
  };

  // 检查任务是否过期
  const isOverdue = () => {
    if (!task.dueDate || task.completed) return false;
    const now = new Date();
    const dueDate = new Date(task.dueDate);
    return dueDate < now;
  };

  return (
    <li className={`task-item ${task.completed ? 'completed' : ''} ${isOverdue() ? 'overdue' : ''}`}>
      <div className="task-checkbox">
        <input
          type="checkbox"
          checked={task.completed}
          onChange={onToggleComplete}
          id={`task-${task._id}`}
        />
        <label htmlFor={`task-${task._id}`}></label>
      </div>
      
      <div className="task-content" onClick={onSelect}>
        <div className="task-title-row">
          <span className={`priority-indicator ${getPriorityClass(task.priority)}`}></span>
          <h4 className="task-title">{task.title}</h4>
        </div>
        
        <div className="task-info">
          {task.dueDate && (
            <span className="task-due-date">
              <i className="fa fa-calendar"></i> {formatDate(task.dueDate)}
            </span>
          )}
          
          <span className="task-pomodoros">
            <i className="fa fa-clock"></i> {task.actualPomodoros}/{task.estimatedPomodoros}
          </span>
          
          {task.category && (
            <span className="task-category">
              <i className="fa fa-tag"></i> {task.category}
            </span>
          )}
        </div>
      </div>
    </li>
  );
};

export default TaskItem;
