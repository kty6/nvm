import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import axios from 'axios';
import { 
  setProvider, 
  setApiEndpoint, 
  setApiKey,
  setTaskBreakdownPrompt,
  setTimeManagementPrompt,
  setPrioritizationPrompt,
  addCustomPrompt,
  removeCustomPrompt,
  aiRequestStart,
  aiRequestSuccess,
  aiRequestFailure
} from '../../store/slices/aiSlice';

const AISettings = () => {
  const dispatch = useDispatch();
  const { 
    provider, 
    apiEndpoint, 
    apiKey, 
    isConfigured,
    taskBreakdownPrompt,
    timeManagementPrompt,
    prioritizationPrompt,
    customPrompts
  } = useSelector(state => state.ai);
  
  const [formData, setFormData] = useState({
    provider: 'openai',
    apiEndpoint: 'https://api.openai.com/v1/chat/completions',
    apiKey: '',
    taskBreakdownPrompt: '请将以下任务拆分为更小的子任务，并为每个子任务提供时间估计：',
    timeManagementPrompt: '请根据我的日程和任务列表，提供时间管理优化建议：',
    prioritizationPrompt: '请帮我对以下任务进行优先级排序：'
  });
  
  const [customPromptName, setCustomPromptName] = useState('');
  const [customPromptText, setCustomPromptText] = useState('');
  const [saving, setSaving] = useState(false);
  const [testingConnection, setTestingConnection] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState(null);
  const [error, setError] = useState(null);

  // 初始化表单数据
  useEffect(() => {
    setFormData({
      provider,
      apiEndpoint,
      apiKey: apiKey ? '********' : '',
      taskBreakdownPrompt,
      timeManagementPrompt,
      prioritizationPrompt
    });
  }, [provider, apiEndpoint, apiKey, taskBreakdownPrompt, timeManagementPrompt, prioritizationPrompt]);

  // 处理输入变化
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  // 处理自定义提示词名称变化
  const handleCustomPromptNameChange = (e) => {
    setCustomPromptName(e.target.value);
  };

  // 处理自定义提示词文本变化
  const handleCustomPromptTextChange = (e) => {
    setCustomPromptText(e.target.value);
  };

  // 添加自定义提示词
  const handleAddCustomPrompt = () => {
    if (customPromptName.trim() && customPromptText.trim()) {
      dispatch(addCustomPrompt({
        name: customPromptName.trim(),
        prompt: customPromptText.trim()
      }));
      setCustomPromptName('');
      setCustomPromptText('');
    }
  };

  // 删除自定义提示词
  const handleRemoveCustomPrompt = (name) => {
    dispatch(removeCustomPrompt(name));
  };

  // 测试AI连接
  const handleTestConnection = async () => {
    setTestingConnection(true);
    setConnectionStatus(null);
    setError(null);
    
    try {
      const token = localStorage.getItem('token');
      const testPrompt = "测试连接，请回复'连接成功'";
      
      const res = await axios.post('/api/ai/custom-prompt', 
        { prompt: testPrompt },
        {
          headers: {
            'x-auth-token': token,
            'Content-Type': 'application/json'
          }
        }
      );
      
      setConnectionStatus('success');
    } catch (err) {
      setConnectionStatus('error');
      setError(err.response?.data?.msg || '连接测试失败');
    } finally {
      setTestingConnection(false);
    }
  };

  // 保存设置
  const handleSaveSettings = async () => {
    setSaving(true);
    setError(null);
    
    try {
      const token = localStorage.getItem('token');
      const settingsData = {
        settings: {
          aiProvider: formData.provider,
          apiEndpoint: formData.apiEndpoint,
          apiKey: formData.apiKey === '********' ? undefined : formData.apiKey
        }
      };
      
      await axios.put('/api/auth/user', settingsData, {
        headers: {
          'x-auth-token': token,
          'Content-Type': 'application/json'
        }
      });
      
      // 更新Redux状态
      if (formData.apiKey !== '********') {
        dispatch(setApiKey(formData.apiKey));
      }
      dispatch(setProvider(formData.provider));
      dispatch(setApiEndpoint(formData.apiEndpoint));
      dispatch(setTaskBreakdownPrompt(formData.taskBreakdownPrompt));
      dispatch(setTimeManagementPrompt(formData.timeManagementPrompt));
      dispatch(setPrioritizationPrompt(formData.prioritizationPrompt));
      
      alert('设置已保存');
    } catch (err) {
      setError(err.response?.data?.msg || '保存设置失败');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="ai-settings">
      <h3>AI设置</h3>
      
      <div className="settings-section">
        <h4>AI提供商配置</h4>
        
        <div className="form-group">
          <label>AI提供商</label>
          <select
            name="provider"
            value={formData.provider}
            onChange={handleChange}
            className="form-control"
          >
            <option value="openai">OpenAI</option>
            <option value="anthropic">Anthropic</option>
            <option value="custom">自定义</option>
          </select>
        </div>
        
        <div className="form-group">
          <label>API端点</label>
          <input
            type="text"
            name="apiEndpoint"
            value={formData.apiEndpoint}
            onChange={handleChange}
            className="form-control"
            placeholder="例如: https://api.openai.com/v1/chat/completions"
          />
        </div>
        
        <div className="form-group">
          <label>API密钥</label>
          <input
            type="password"
            name="apiKey"
            value={formData.apiKey}
            onChange={handleChange}
            className="form-control"
            placeholder="输入您的API密钥"
          />
          <small className="form-text text-muted">
            如果不修改密钥，请保留星号。
          </small>
        </div>
        
        <div className="connection-test">
          <button 
            onClick={handleTestConnection} 
            className="btn btn-outline-primary"
            disabled={testingConnection}
          >
            {testingConnection ? '测试中...' : '测试连接'}
          </button>
          
          {connectionStatus === 'success' && (
            <span className="connection-success">连接成功！</span>
          )}
          
          {connectionStatus === 'error' && (
            <span className="connection-error">连接失败: {error}</span>
          )}
        </div>
      </div>
      
      <div className="settings-section">
        <h4>提示词模板</h4>
        
        <div className="form-group">
          <label>任务拆分提示词</label>
          <textarea
            name="taskBreakdownPrompt"
            value={formData.taskBreakdownPrompt}
            onChange={handleChange}
            className="form-control"
            rows="3"
          />
        </div>
        
        <div className="form-group">
          <label>时间管理提示词</label>
          <textarea
            name="timeManagementPrompt"
            value={formData.timeManagementPrompt}
            onChange={handleChange}
            className="form-control"
            rows="3"
          />
        </div>
        
        <div className="form-group">
          <label>任务优先级提示词</label>
          <textarea
            name="prioritizationPrompt"
            value={formData.prioritizationPrompt}
            onChange={handleChange}
            className="form-control"
            rows="3"
          />
        </div>
      </div>
      
      <div className="settings-section">
        <h4>自定义提示词</h4>
        
        <div className="custom-prompts-list">
          {Object.entries(customPrompts).map(([name, prompt]) => (
            <div key={name} className="custom-prompt-item">
              <div className="custom-prompt-header">
                <h5>{name}</h5>
                <button 
                  onClick={() => handleRemoveCustomPrompt(name)}
                  className="btn btn-sm btn-danger"
                >
                  删除
                </button>
              </div>
              <p>{prompt}</p>
            </div>
          ))}
        </div>
        
        <div className="add-custom-prompt">
          <div className="form-group">
            <label>名称</label>
            <input
              type="text"
              value={customPromptName}
              onChange={handleCustomPromptNameChange}
              className="form-control"
              placeholder="提示词名称"
            />
          </div>
          
          <div className="form-group">
            <label>提示词内容</label>
            <textarea
              value={customPromptText}
              onChange={handleCustomPromptTextChange}
              className="form-control"
              rows="3"
              placeholder="输入提示词内容"
            />
          </div>
          
          <button 
            onClick={handleAddCustomPrompt}
            className="btn btn-outline-primary"
            disabled={!customPromptName.trim() || !customPromptText.trim()}
          >
            添加提示词
          </button>
        </div>
      </div>
      
      {error && <div className="alert alert-danger">{error}</div>}
      
      <div className="settings-actions">
        <button 
          onClick={handleSaveSettings}
          className="btn btn-primary"
          disabled={saving}
        >
          {saving ? '保存中...' : '保存设置'}
        </button>
      </div>
    </div>
  );
};

export default AISettings;
