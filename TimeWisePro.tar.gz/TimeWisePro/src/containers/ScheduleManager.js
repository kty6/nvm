import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Calendar, momentLocalizer } from 'react-big-calendar';
import moment from 'moment';
import 'react-big-calendar/lib/css/react-big-calendar.css';
import { fetchSchedulesStart, fetchSchedulesSuccess, fetchSchedulesFailure, setCurrentSchedule } from '../../store/slices/scheduleSlice';
import ScheduleForm from './ScheduleForm';
import ScheduleDetail from './ScheduleDetail';
import axios from 'axios';

// 设置本地化
moment.locale('zh-cn');
const localizer = momentLocalizer(moment);

const ScheduleManager = () => {
  const dispatch = useDispatch();
  const { schedules, loading, error, currentSchedule } = useSelector(state => state.schedule);
  const [showForm, setShowForm] = useState(false);
  const [showDetail, setShowDetail] = useState(false);
  const [editMode, setEditMode] = useState(false);

  // 获取所有日程
  useEffect(() => {
    const fetchSchedules = async () => {
      try {
        dispatch(fetchSchedulesStart());
        const token = localStorage.getItem('token');
        const res = await axios.get('/api/schedules', {
          headers: {
            'x-auth-token': token
          }
        });
        dispatch(fetchSchedulesSuccess(res.data));
      } catch (err) {
        dispatch(fetchSchedulesFailure(err.response?.data?.msg || '获取日程失败'));
      }
    };

    fetchSchedules();
  }, [dispatch]);

  // 处理日程点击
  const handleSelectEvent = (event) => {
    dispatch(setCurrentSchedule(event));
    setShowDetail(true);
    setShowForm(false);
  };

  // 处理日期选择
  const handleSelectSlot = ({ start, end }) => {
    dispatch(setCurrentSchedule({
      title: '',
      description: '',
      startTime: start,
      endTime: end,
      location: '',
      isAllDay: false,
      recurrence: {
        type: 'none',
        interval: 1
      },
      reminder: {
        enabled: false,
        time: 15
      },
      category: '默认',
      tags: [],
      priority: 3
    }));
    setShowForm(true);
    setEditMode(false);
    setShowDetail(false);
  };

  // 处理新建日程
  const handleNewSchedule = () => {
    dispatch(setCurrentSchedule({
      title: '',
      description: '',
      startTime: new Date(),
      endTime: new Date(new Date().getTime() + 60 * 60 * 1000), // 默认1小时
      location: '',
      isAllDay: false,
      recurrence: {
        type: 'none',
        interval: 1
      },
      reminder: {
        enabled: false,
        time: 15
      },
      category: '默认',
      tags: [],
      priority: 3
    }));
    setShowForm(true);
    setEditMode(false);
    setShowDetail(false);
  };

  // 处理编辑日程
  const handleEditSchedule = () => {
    setShowForm(true);
    setEditMode(true);
    setShowDetail(false);
  };

  // 处理关闭表单
  const handleCloseForm = () => {
    setShowForm(false);
    setEditMode(false);
  };

  // 处理关闭详情
  const handleCloseDetail = () => {
    setShowDetail(false);
    dispatch(setCurrentSchedule(null));
  };

  // 格式化日程数据以适应Calendar组件
  const formattedEvents = schedules.map(schedule => ({
    ...schedule,
    start: new Date(schedule.startTime),
    end: new Date(schedule.endTime),
    title: schedule.title
  }));

  return (
    <div className="schedule-manager">
      <div className="schedule-header">
        <h2>日程管理</h2>
        <button onClick={handleNewSchedule} className="btn btn-primary">
          新建日程
        </button>
      </div>

      {loading ? (
        <div className="loading">加载中...</div>
      ) : error ? (
        <div className="error">{error}</div>
      ) : (
        <div className="calendar-container">
          <Calendar
            localizer={localizer}
            events={formattedEvents}
            startAccessor="start"
            endAccessor="end"
            style={{ height: 500 }}
            onSelectEvent={handleSelectEvent}
            onSelectSlot={handleSelectSlot}
            selectable
            views={['month', 'week', 'day', 'agenda']}
            messages={{
              today: '今天',
              previous: '上一页',
              next: '下一页',
              month: '月',
              week: '周',
              day: '日',
              agenda: '议程'
            }}
          />
        </div>
      )}

      {showForm && (
        <ScheduleForm
          schedule={currentSchedule}
          editMode={editMode}
          onClose={handleCloseForm}
        />
      )}

      {showDetail && (
        <ScheduleDetail
          schedule={currentSchedule}
          onEdit={handleEditSchedule}
          onClose={handleCloseDetail}
        />
      )}
    </div>
  );
};

export default ScheduleManager;
