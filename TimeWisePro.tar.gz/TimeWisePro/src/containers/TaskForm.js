import React, { useState, useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { addTask, updateTask } from '../../store/slices/todoSlice';
import axios from 'axios';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';

const TaskForm = ({ task, editMode, onClose }) => {
  const dispatch = useDispatch();
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    dueDate: null,
    parentTaskId: null,
    category: '默认',
    tags: [],
    priority: 3,
    estimatedPomodoros: 1
  });
  const [tagInput, setTagInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // 初始化表单数据
  useEffect(() => {
    if (task) {
      setFormData({
        ...task,
        dueDate: task.dueDate ? new Date(task.dueDate) : null
      });
    }
  }, [task]);

  // 处理输入变化
  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  // 处理日期变化
  const handleDateChange = (date) => {
    setFormData(prev => ({
      ...prev,
      dueDate: date
    }));
  };

  // 处理标签输入
  const handleTagInputChange = (e) => {
    setTagInput(e.target.value);
  };

  // 添加标签
  const handleAddTag = () => {
    if (tagInput.trim() && !formData.tags.includes(tagInput.trim())) {
      setFormData(prev => ({
        ...prev,
        tags: [...prev.tags, tagInput.trim()]
      }));
      setTagInput('');
    }
  };

  // 删除标签
  const handleRemoveTag = (tag) => {
    setFormData(prev => ({
      ...prev,
      tags: prev.tags.filter(t => t !== tag)
    }));
  };

  // 处理表单提交
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const token = localStorage.getItem('token');
      
      if (editMode) {
        // 更新任务
        const res = await axios.put(`/api/tasks/${task._id}`, formData, {
          headers: {
            'x-auth-token': token,
            'Content-Type': 'application/json'
          }
        });
        dispatch(updateTask(res.data));
      } else {
        // 创建新任务
        const res = await axios.post('/api/tasks', formData, {
          headers: {
            'x-auth-token': token,
            'Content-Type': 'application/json'
          }
        });
        dispatch(addTask(res.data));
      }
      
      onClose();
    } catch (err) {
      setError(err.response?.data?.msg || '保存任务失败');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="task-form-modal">
      <div className="modal-content">
        <div className="modal-header">
          <h3>{editMode ? '编辑任务' : '新建任务'}</h3>
          <button onClick={onClose} className="close-btn">&times;</button>
        </div>
        
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>标题</label>
            <input
              type="text"
              name="title"
              value={formData.title}
              onChange={handleChange}
              className="form-control"
              required
            />
          </div>
          
          <div className="form-group">
            <label>描述</label>
            <textarea
              name="description"
              value={formData.description}
              onChange={handleChange}
              className="form-control"
              rows="3"
            />
          </div>
          
          <div className="form-group">
            <label>截止日期</label>
            <DatePicker
              selected={formData.dueDate}
              onChange={handleDateChange}
              dateFormat="yyyy-MM-dd"
              className="form-control"
              isClearable
              placeholderText="无截止日期"
            />
          </div>
          
          <div className="form-group">
            <label>类别</label>
            <input
              type="text"
              name="category"
              value={formData.category}
              onChange={handleChange}
              className="form-control"
            />
          </div>
          
          <div className="form-group">
            <label>标签</label>
            <div className="input-group">
              <input
                type="text"
                value={tagInput}
                onChange={handleTagInputChange}
                className="form-control"
                placeholder="输入标签后按添加"
              />
              <button
                type="button"
                onClick={handleAddTag}
                className="btn btn-outline-secondary"
              >
                添加
              </button>
            </div>
            
            <div className="tags-container mt-2">
              {formData.tags.map(tag => (
                <span key={tag} className="badge bg-primary me-1">
                  {tag}
                  <button
                    type="button"
                    onClick={() => handleRemoveTag(tag)}
                    className="btn-close btn-close-white ms-1"
                    aria-label="删除"
                  ></button>
                </span>
              ))}
            </div>
          </div>
          
          <div className="form-group">
            <label>优先级</label>
            <select
              name="priority"
              value={formData.priority}
              onChange={handleChange}
              className="form-control"
            >
              <option value="1">很低</option>
              <option value="2">低</option>
              <option value="3">中</option>
              <option value="4">高</option>
              <option value="5">很高</option>
            </select>
          </div>
          
          <div className="form-group">
            <label>预计番茄钟数量</label>
            <input
              type="number"
              name="estimatedPomodoros"
              value={formData.estimatedPomodoros}
              onChange={handleChange}
              className="form-control"
              min="1"
            />
          </div>
          
          {error && <div className="alert alert-danger">{error}</div>}
          
          <div className="modal-footer">
            <button type="button" onClick={onClose} className="btn btn-secondary">
              取消
            </button>
            <button type="submit" className="btn btn-primary" disabled={loading}>
              {loading ? '保存中...' : '保存'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default TaskForm;
