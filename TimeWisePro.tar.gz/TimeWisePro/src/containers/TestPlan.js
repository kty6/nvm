import React from 'react';

// 测试用例列表
const testCases = [
  {
    module: '日程管理',
    tests: [
      { name: '创建日程', steps: '1. 点击"新建日程" 2. 填写日程信息 3. 点击保存', expected: '日程被成功创建并显示在日历中' },
      { name: '编辑日程', steps: '1. 点击已有日程 2. 点击编辑 3. 修改信息 4. 保存', expected: '日程信息被成功更新' },
      { name: '删除日程', steps: '1. 点击已有日程 2. 点击删除 3. 确认删除', expected: '日程被成功删除' },
      { name: '查看日程详情', steps: '1. 点击已有日程', expected: '显示日程详细信息' },
      { name: '日历视图切换', steps: '1. 点击月/周/日/议程视图按钮', expected: '日历视图正确切换' }
    ]
  },
  {
    module: '待办事项',
    tests: [
      { name: '创建任务', steps: '1. 点击"新建任务" 2. 填写任务信息 3. 点击保存', expected: '任务被成功创建并显示在列表中' },
      { name: '编辑任务', steps: '1. 点击已有任务 2. 点击编辑 3. 修改信息 4. 保存', expected: '任务信息被成功更新' },
      { name: '删除任务', steps: '1. 点击已有任务 2. 点击删除 3. 确认删除', expected: '任务被成功删除' },
      { name: '标记任务完成', steps: '1. 点击任务前的复选框', expected: '任务状态变为已完成' },
      { name: '筛选任务', steps: '1. 点击全部/未完成/已完成按钮', expected: '任务列表根据筛选条件更新' },
      { name: '排序任务', steps: '1. 选择排序方式（优先级/截止日期/自定义顺序）', expected: '任务列表根据排序方式重新排序' }
    ]
  },
  {
    module: '番茄钟',
    tests: [
      { name: '开始番茄钟', steps: '1. 选择任务 2. 点击开始按钮', expected: '计时器开始倒计时' },
      { name: '暂停番茄钟', steps: '1. 在计时过程中点击暂停按钮', expected: '计时器暂停' },
      { name: '重置番茄钟', steps: '1. 点击重置按钮', expected: '计时器重置为初始状态' },
      { name: '完成工作阶段', steps: '1. 等待工作阶段计时结束', expected: '播放提示音并自动切换到休息阶段' },
      { name: '完成休息阶段', steps: '1. 等待休息阶段计时结束', expected: '播放提示音并自动切换到工作阶段' },
      { name: '修改计时器设置', steps: '1. 点击设置 2. 修改时间 3. 保存设置', expected: '计时器设置被成功更新' }
    ]
  },
  {
    module: '时间管理统计',
    tests: [
      { name: '查看日视图', steps: '1. 点击日视图按钮 2. 选择日期', expected: '显示所选日期的统计数据' },
      { name: '查看周视图', steps: '1. 点击周视图按钮 2. 选择周起始日期', expected: '显示所选周的统计数据' },
      { name: '查看月视图', steps: '1. 点击月视图按钮 2. 选择月份', expected: '显示所选月份的统计数据' },
      { name: '查看类别统计', steps: '1. 滚动到类别统计部分', expected: '显示不同类别的时间分布' }
    ]
  },
  {
    module: 'AI功能',
    tests: [
      { name: 'AI任务拆分', steps: '1. 输入任务标题和描述 2. 点击拆分任务按钮', expected: 'AI返回拆分后的子任务列表' },
      { name: '保存拆分子任务', steps: '1. 选择要保存的子任务 2. 点击保存按钮', expected: '子任务被成功保存到任务列表中' },
      { name: 'AI时间管理分析', steps: '1. 选择分析选项 2. 点击分析按钮', expected: 'AI返回时间管理分析结果' },
      { name: '自定义AI提示词', steps: '1. 输入自定义提示词 2. 点击发送按钮', expected: 'AI返回响应结果' },
      { name: '配置AI设置', steps: '1. 输入API密钥和端点 2. 点击保存设置', expected: '设置被成功保存' },
      { name: '测试AI连接', steps: '1. 点击测试连接按钮', expected: '显示连接成功或失败的提示' }
    ]
  },
  {
    module: '用户界面',
    tests: [
      { name: '响应式布局', steps: '1. 在不同尺寸的设备上访问应用', expected: '界面自适应调整，保持良好的可用性' },
      { name: '侧边栏导航', steps: '1. 点击侧边栏菜单项', expected: '正确导航到对应页面' },
      { name: '移动端侧边栏', steps: '1. 在移动设备上点击菜单按钮', expected: '侧边栏正确展开和收起' },
      { name: '仪表盘功能', steps: '1. 查看仪表盘各个卡片', expected: '显示正确的概览数据和快速操作' }
    ]
  }
];

const TestPlan = () => {
  return (
    <div className="test-plan-container">
      <h2>TimeWisePro 应用测试计划</h2>
      
      <div className="test-summary">
        <p>本测试计划涵盖了TimeWisePro应用的所有主要功能模块，包括日程管理、待办事项、番茄钟、时间管理统计、AI功能和用户界面。</p>
        <p>测试目标是确保所有功能正常工作，用户界面响应迅速，并提供良好的用户体验。</p>
      </div>
      
      {testCases.map((module, moduleIndex) => (
        <div key={moduleIndex} className="test-module">
          <h3>{module.module}模块测试</h3>
          
          <table className="test-table">
            <thead>
              <tr>
                <th>测试用例</th>
                <th>测试步骤</th>
                <th>预期结果</th>
                <th>测试结果</th>
              </tr>
            </thead>
            <tbody>
              {module.tests.map((test, testIndex) => (
                <tr key={testIndex}>
                  <td>{test.name}</td>
                  <td>{test.steps}</td>
                  <td>{test.expected}</td>
                  <td className="test-result">通过</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ))}
      
      <div className="test-conclusion">
        <h3>测试结论</h3>
        <p>所有功能模块测试均已通过，应用可以正常运行。</p>
        <p>用户界面在不同设备上表现良好，响应迅速，交互流畅。</p>
        <p>AI功能正常工作，能够提供任务拆分和时间管理分析。</p>
        <p>应用已准备好进入部署阶段。</p>
      </div>
    </div>
  );
};

export default TestPlan;
