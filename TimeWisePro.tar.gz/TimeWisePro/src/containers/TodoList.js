import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { 
  fetchTasksStart, 
  fetchTasksSuccess, 
  fetchTasksFailure, 
  setCurrentTask,
  toggleTaskCompletion
} from '../../store/slices/todoSlice';
import TaskForm from './TaskForm';
import TaskDetail from './TaskDetail';
import TaskItem from './TaskItem';
import axios from 'axios';

const TodoList = () => {
  const dispatch = useDispatch();
  const { tasks, loading, error, currentTask } = useSelector(state => state.todo);
  const [showForm, setShowForm] = useState(false);
  const [showDetail, setShowDetail] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [filter, setFilter] = useState('all'); // all, active, completed
  const [sortBy, setSortBy] = useState('priority'); // priority, dueDate, order

  // 获取所有任务
  useEffect(() => {
    const fetchTasks = async () => {
      try {
        dispatch(fetchTasksStart());
        const token = localStorage.getItem('token');
        const res = await axios.get('/api/tasks', {
          headers: {
            'x-auth-token': token
          }
        });
        dispatch(fetchTasksSuccess(res.data));
      } catch (err) {
        dispatch(fetchTasksFailure(err.response?.data?.msg || '获取任务失败'));
      }
    };

    fetchTasks();
  }, [dispatch]);

  // 处理任务点击
  const handleSelectTask = (task) => {
    dispatch(setCurrentTask(task));
    setShowDetail(true);
    setShowForm(false);
  };

  // 处理新建任务
  const handleNewTask = () => {
    dispatch(setCurrentTask({
      title: '',
      description: '',
      dueDate: null,
      completed: false,
      parentTaskId: null,
      category: '默认',
      tags: [],
      priority: 3,
      estimatedPomodoros: 1,
      actualPomodoros: 0
    }));
    setShowForm(true);
    setEditMode(false);
    setShowDetail(false);
  };

  // 处理编辑任务
  const handleEditTask = () => {
    setShowForm(true);
    setEditMode(true);
    setShowDetail(false);
  };

  // 处理关闭表单
  const handleCloseForm = () => {
    setShowForm(false);
    setEditMode(false);
  };

  // 处理关闭详情
  const handleCloseDetail = () => {
    setShowDetail(false);
    dispatch(setCurrentTask(null));
  };

  // 处理任务完成状态切换
  const handleToggleComplete = async (taskId) => {
    try {
      const token = localStorage.getItem('token');
      await axios.put(`/api/tasks/${taskId}/toggle`, {}, {
        headers: {
          'x-auth-token': token
        }
      });
      dispatch(toggleTaskCompletion(taskId));
    } catch (err) {
      console.error('切换任务状态失败:', err);
    }
  };

  // 过滤任务
  const filteredTasks = tasks.filter(task => {
    if (filter === 'all') return true;
    if (filter === 'active') return !task.completed;
    if (filter === 'completed') return task.completed;
    return true;
  });

  // 排序任务
  const sortedTasks = [...filteredTasks].sort((a, b) => {
    if (sortBy === 'priority') return b.priority - a.priority;
    if (sortBy === 'dueDate') {
      if (!a.dueDate) return 1;
      if (!b.dueDate) return -1;
      return new Date(a.dueDate) - new Date(b.dueDate);
    }
    if (sortBy === 'order') return a.order - b.order;
    return 0;
  });

  return (
    <div className="todo-list">
      <div className="todo-header">
        <h2>待办事项</h2>
        <button onClick={handleNewTask} className="btn btn-primary">
          新建任务
        </button>
      </div>

      <div className="todo-filters">
        <div className="filter-group">
          <span>显示：</span>
          <button 
            className={`btn btn-sm ${filter === 'all' ? 'btn-primary' : 'btn-outline-primary'}`}
            onClick={() => setFilter('all')}
          >
            全部
          </button>
          <button 
            className={`btn btn-sm ${filter === 'active' ? 'btn-primary' : 'btn-outline-primary'}`}
            onClick={() => setFilter('active')}
          >
            未完成
          </button>
          <button 
            className={`btn btn-sm ${filter === 'completed' ? 'btn-primary' : 'btn-outline-primary'}`}
            onClick={() => setFilter('completed')}
          >
            已完成
          </button>
        </div>

        <div className="sort-group">
          <span>排序：</span>
          <select 
            value={sortBy} 
            onChange={(e) => setSortBy(e.target.value)}
            className="form-select form-select-sm"
          >
            <option value="priority">优先级</option>
            <option value="dueDate">截止日期</option>
            <option value="order">自定义顺序</option>
          </select>
        </div>
      </div>

      {loading ? (
        <div className="loading">加载中...</div>
      ) : error ? (
        <div className="error">{error}</div>
      ) : (
        <div className="tasks-container">
          {sortedTasks.length === 0 ? (
            <div className="no-tasks">暂无任务</div>
          ) : (
            <ul className="task-list">
              {sortedTasks.map(task => (
                <TaskItem 
                  key={task._id}
                  task={task}
                  onSelect={() => handleSelectTask(task)}
                  onToggleComplete={() => handleToggleComplete(task._id)}
                />
              ))}
            </ul>
          )}
        </div>
      )}

      {showForm && (
        <TaskForm
          task={currentTask}
          editMode={editMode}
          onClose={handleCloseForm}
        />
      )}

      {showDetail && (
        <TaskDetail
          task={currentTask}
          onEdit={handleEditTask}
          onClose={handleCloseDetail}
          onToggleComplete={() => handleToggleComplete(currentTask._id)}
        />
      )}
    </div>
  );
};

export default TodoList;
