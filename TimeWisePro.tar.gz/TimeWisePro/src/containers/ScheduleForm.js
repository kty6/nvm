import React, { useState, useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { addSchedule, updateSchedule } from '../../store/slices/scheduleSlice';
import axios from 'axios';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';

const ScheduleForm = ({ schedule, editMode, onClose }) => {
  const dispatch = useDispatch();
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    startTime: new Date(),
    endTime: new Date(new Date().getTime() + 60 * 60 * 1000), // 默认1小时
    location: '',
    isAllDay: false,
    recurrence: {
      type: 'none',
      interval: 1,
      endDate: null
    },
    reminder: {
      enabled: false,
      time: 15
    },
    category: '默认',
    tags: [],
    priority: 3
  });
  const [tagInput, setTagInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // 初始化表单数据
  useEffect(() => {
    if (schedule) {
      setFormData({
        ...schedule,
        startTime: new Date(schedule.startTime),
        endTime: new Date(schedule.endTime),
        recurrence: {
          ...schedule.recurrence,
          endDate: schedule.recurrence.endDate ? new Date(schedule.recurrence.endDate) : null
        }
      });
    }
  }, [schedule]);

  // 处理输入变化
  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    
    if (name.includes('.')) {
      const [parent, child] = name.split('.');
      setFormData(prev => ({
        ...prev,
        [parent]: {
          ...prev[parent],
          [child]: type === 'checkbox' ? checked : value
        }
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        [name]: type === 'checkbox' ? checked : value
      }));
    }
  };

  // 处理日期变化
  const handleDateChange = (date, name) => {
    if (name.includes('.')) {
      const [parent, child] = name.split('.');
      setFormData(prev => ({
        ...prev,
        [parent]: {
          ...prev[parent],
          [child]: date
        }
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        [name]: date
      }));
    }
  };

  // 处理标签输入
  const handleTagInputChange = (e) => {
    setTagInput(e.target.value);
  };

  // 添加标签
  const handleAddTag = () => {
    if (tagInput.trim() && !formData.tags.includes(tagInput.trim())) {
      setFormData(prev => ({
        ...prev,
        tags: [...prev.tags, tagInput.trim()]
      }));
      setTagInput('');
    }
  };

  // 删除标签
  const handleRemoveTag = (tag) => {
    setFormData(prev => ({
      ...prev,
      tags: prev.tags.filter(t => t !== tag)
    }));
  };

  // 处理表单提交
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const token = localStorage.getItem('token');
      
      if (editMode) {
        // 更新日程
        const res = await axios.put(`/api/schedules/${schedule._id}`, formData, {
          headers: {
            'x-auth-token': token,
            'Content-Type': 'application/json'
          }
        });
        dispatch(updateSchedule(res.data));
      } else {
        // 创建新日程
        const res = await axios.post('/api/schedules', formData, {
          headers: {
            'x-auth-token': token,
            'Content-Type': 'application/json'
          }
        });
        dispatch(addSchedule(res.data));
      }
      
      onClose();
    } catch (err) {
      setError(err.response?.data?.msg || '保存日程失败');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="schedule-form-modal">
      <div className="modal-content">
        <div className="modal-header">
          <h3>{editMode ? '编辑日程' : '新建日程'}</h3>
          <button onClick={onClose} className="close-btn">&times;</button>
        </div>
        
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>标题</label>
            <input
              type="text"
              name="title"
              value={formData.title}
              onChange={handleChange}
              className="form-control"
              required
            />
          </div>
          
          <div className="form-group">
            <label>描述</label>
            <textarea
              name="description"
              value={formData.description}
              onChange={handleChange}
              className="form-control"
              rows="3"
            />
          </div>
          
          <div className="form-check mb-3">
            <input
              type="checkbox"
              name="isAllDay"
              checked={formData.isAllDay}
              onChange={handleChange}
              className="form-check-input"
              id="isAllDay"
            />
            <label className="form-check-label" htmlFor="isAllDay">
              全天事件
            </label>
          </div>
          
          <div className="row">
            <div className="col">
              <div className="form-group">
                <label>开始时间</label>
                <DatePicker
                  selected={formData.startTime}
                  onChange={(date) => handleDateChange(date, 'startTime')}
                  showTimeSelect={!formData.isAllDay}
                  dateFormat={formData.isAllDay ? "yyyy-MM-dd" : "yyyy-MM-dd HH:mm"}
                  className="form-control"
                />
              </div>
            </div>
            
            <div className="col">
              <div className="form-group">
                <label>结束时间</label>
                <DatePicker
                  selected={formData.endTime}
                  onChange={(date) => handleDateChange(date, 'endTime')}
                  showTimeSelect={!formData.isAllDay}
                  dateFormat={formData.isAllDay ? "yyyy-MM-dd" : "yyyy-MM-dd HH:mm"}
                  className="form-control"
                  minDate={formData.startTime}
                />
              </div>
            </div>
          </div>
          
          <div className="form-group">
            <label>地点</label>
            <input
              type="text"
              name="location"
              value={formData.location}
              onChange={handleChange}
              className="form-control"
            />
          </div>
          
          <div className="form-group">
            <label>重复</label>
            <select
              name="recurrence.type"
              value={formData.recurrence.type}
              onChange={handleChange}
              className="form-control"
            >
              <option value="none">不重复</option>
              <option value="daily">每天</option>
              <option value="weekly">每周</option>
              <option value="monthly">每月</option>
              <option value="yearly">每年</option>
            </select>
          </div>
          
          {formData.recurrence.type !== 'none' && (
            <>
              <div className="form-group">
                <label>间隔</label>
                <input
                  type="number"
                  name="recurrence.interval"
                  value={formData.recurrence.interval}
                  onChange={handleChange}
                  className="form-control"
                  min="1"
                />
              </div>
              
              <div className="form-group">
                <label>结束日期</label>
                <DatePicker
                  selected={formData.recurrence.endDate}
                  onChange={(date) => handleDateChange(date, 'recurrence.endDate')}
                  dateFormat="yyyy-MM-dd"
                  className="form-control"
                  minDate={formData.startTime}
                  isClearable
                  placeholderText="永不结束"
                />
              </div>
            </>
          )}
          
          <div className="form-check mb-3">
            <input
              type="checkbox"
              name="reminder.enabled"
              checked={formData.reminder.enabled}
              onChange={handleChange}
              className="form-check-input"
              id="reminderEnabled"
            />
            <label className="form-check-label" htmlFor="reminderEnabled">
              启用提醒
            </label>
          </div>
          
          {formData.reminder.enabled && (
            <div className="form-group">
              <label>提前提醒时间（分钟）</label>
              <input
                type="number"
                name="reminder.time"
                value={formData.reminder.time}
                onChange={handleChange}
                className="form-control"
                min="0"
              />
            </div>
          )}
          
          <div className="form-group">
            <label>类别</label>
            <input
              type="text"
              name="category"
              value={formData.category}
              onChange={handleChange}
              className="form-control"
            />
          </div>
          
          <div className="form-group">
            <label>标签</label>
            <div className="input-group">
              <input
                type="text"
                value={tagInput}
                onChange={handleTagInputChange}
                className="form-control"
                placeholder="输入标签后按添加"
              />
              <button
                type="button"
                onClick={handleAddTag}
                className="btn btn-outline-secondary"
              >
                添加
              </button>
            </div>
            
            <div className="tags-container mt-2">
              {formData.tags.map(tag => (
                <span key={tag} className="badge bg-primary me-1">
                  {tag}
                  <button
                    type="button"
                    onClick={() => handleRemoveTag(tag)}
                    className="btn-close btn-close-white ms-1"
                    aria-label="删除"
                  ></button>
                </span>
              ))}
            </div>
          </div>
          
          <div className="form-group">
            <label>优先级</label>
            <select
              name="priority"
              value={formData.priority}
              onChange={handleChange}
              className="form-control"
            >
              <option value="1">很低</option>
              <option value="2">低</option>
              <option value="3">中</option>
              <option value="4">高</option>
              <option value="5">很高</option>
            </select>
          </div>
          
          {error && <div className="alert alert-danger">{error}</div>}
          
          <div className="modal-footer">
            <button type="button" onClick={onClose} className="btn btn-secondary">
              取消
            </button>
            <button type="submit" className="btn btn-primary" disabled={loading}>
              {loading ? '保存中...' : '保存'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ScheduleForm;
