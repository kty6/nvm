import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import axios from 'axios';

const TaskSelector = ({ tasks, selectedTaskId, onSelectTask }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredTasks, setFilteredTasks] = useState(tasks);

  // 当任务列表或搜索词变化时，更新过滤后的任务
  useEffect(() => {
    if (searchTerm.trim() === '') {
      setFilteredTasks(tasks);
    } else {
      const filtered = tasks.filter(task => 
        task.title.toLowerCase().includes(searchTerm.toLowerCase())
      );
      setFilteredTasks(filtered);
    }
  }, [tasks, searchTerm]);

  // 处理搜索输入变化
  const handleSearchChange = (e) => {
    setSearchTerm(e.target.value);
  };

  // 处理任务选择
  const handleTaskSelect = (e) => {
    const taskId = e.target.value;
    onSelectTask(taskId === 'none' ? null : taskId);
  };

  return (
    <div className="task-selector">
      <div className="search-container">
        <input
          type="text"
          placeholder="搜索任务..."
          value={searchTerm}
          onChange={handleSearchChange}
          className="form-control"
        />
      </div>
      
      <select
        value={selectedTaskId || 'none'}
        onChange={handleTaskSelect}
        className="form-select mt-2"
      >
        <option value="none">-- 不关联任务 --</option>
        {filteredTasks.map(task => (
          <option key={task._id} value={task._id}>
            {task.title}
          </option>
        ))}
      </select>
    </div>
  );
};

export default TaskSelector;
