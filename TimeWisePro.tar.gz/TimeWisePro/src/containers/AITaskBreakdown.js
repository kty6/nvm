import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import axios from 'axios';
import { 
  aiRequestStart, 
  aiRequestSuccess, 
  aiRequestFailure 
} from '../../store/slices/aiSlice';
import { addTask } from '../../store/slices/todoSlice';

const AITaskBreakdown = () => {
  const dispatch = useDispatch();
  const { isConfigured, loading, error, lastResponse } = useSelector(state => state.ai);
  const [taskTitle, setTaskTitle] = useState('');
  const [taskDescription, setTaskDescription] = useState('');
  const [additionalContext, setAdditionalContext] = useState('');
  const [breakdownResult, setBreakdownResult] = useState(null);
  const [parsedSubtasks, setParsedSubtasks] = useState([]);
  const [selectedSubtasks, setSelectedSubtasks] = useState([]);
  const [savingSubtasks, setSavingSubtasks] = useState(false);

  // 重置解析的子任务
  useEffect(() => {
    setParsedSubtasks([]);
    setSelectedSubtasks([]);
  }, [breakdownResult]);

  // 处理任务标题变化
  const handleTaskTitleChange = (e) => {
    setTaskTitle(e.target.value);
  };

  // 处理任务描述变化
  const handleTaskDescriptionChange = (e) => {
    setTaskDescription(e.target.value);
  };

  // 处理附加上下文变化
  const handleAdditionalContextChange = (e) => {
    setAdditionalContext(e.target.value);
  };

  // 处理任务拆分请求
  const handleBreakdownTask = async () => {
    if (!taskTitle.trim()) {
      alert('请输入任务标题');
      return;
    }

    dispatch(aiRequestStart());
    
    try {
      const token = localStorage.getItem('token');
      const taskData = {
        task: taskTitle + (taskDescription ? '\n\n' + taskDescription : ''),
        additionalContext: additionalContext || undefined
      };
      
      const res = await axios.post('/api/ai/task-breakdown', taskData, {
        headers: {
          'x-auth-token': token,
          'Content-Type': 'application/json'
        }
      });
      
      dispatch(aiRequestSuccess(res.data.result));
      setBreakdownResult(res.data.result);
      
      // 尝试解析子任务
      parseSubtasks(res.data.result);
    } catch (err) {
      dispatch(aiRequestFailure(err.response?.data?.msg || '任务拆分请求失败'));
    }
  };

  // 解析AI返回的子任务
  const parseSubtasks = (text) => {
    // 尝试识别常见的列表格式
    const subtaskRegexes = [
      // 1. 任务名称 (2小时)
      /(\d+)\.\s+(.+?)\s*(?:\((\d+(?:\.\d+)?)\s*(?:小时|分钟|时|分|h|m|min|hour|hr)\))?/g,
      // - 任务名称 (2小时)
      /-\s+(.+?)\s*(?:\((\d+(?:\.\d+)?)\s*(?:小时|分钟|时|分|h|m|min|hour|hr)\))?/g,
      // 任务名称：2小时
      /(.+?)：\s*(\d+(?:\.\d+)?)\s*(?:小时|分钟|时|分|h|m|min|hour|hr)/g
    ];
    
    let parsedTasks = [];
    let match;
    
    // 尝试使用不同的正则表达式解析
    for (const regex of subtaskRegexes) {
      const matches = [...text.matchAll(regex)];
      if (matches.length > 0) {
        parsedTasks = matches.map(match => {
          // 根据不同的正则格式处理匹配结果
          if (regex.toString().startsWith('/\\d+')) {
            // 第一种格式: 1. 任务名称 (2小时)
            return {
              title: match[2].trim(),
              estimatedTime: match[3] ? parseFloat(match[3]) : null,
              timeUnit: match[3] && match[3].includes('小时') ? 'hour' : 'minute'
            };
          } else if (regex.toString().startsWith('/-')) {
            // 第二种格式: - 任务名称 (2小时)
            return {
              title: match[1].trim(),
              estimatedTime: match[2] ? parseFloat(match[2]) : null,
              timeUnit: match[2] && match[2].includes('小时') ? 'hour' : 'minute'
            };
          } else {
            // 第三种格式: 任务名称：2小时
            return {
              title: match[1].trim(),
              estimatedTime: match[2] ? parseFloat(match[2]) : null,
              timeUnit: match[0].includes('小时') ? 'hour' : 'minute'
            };
          }
        });
        break;
      }
    }
    
    // 如果没有匹配到任何子任务，尝试按行分割
    if (parsedTasks.length === 0) {
      const lines = text.split('\n').filter(line => line.trim());
      parsedTasks = lines.map(line => ({
        title: line.trim(),
        estimatedTime: null,
        timeUnit: 'hour'
      }));
    }
    
    setParsedSubtasks(parsedTasks);
    setSelectedSubtasks(parsedTasks.map((_, index) => index)); // 默认全选
  };

  // 处理子任务选择变化
  const handleSubtaskSelectionChange = (index) => {
    setSelectedSubtasks(prev => {
      if (prev.includes(index)) {
        return prev.filter(i => i !== index);
      } else {
        return [...prev, index];
      }
    });
  };

  // 处理全选/取消全选
  const handleToggleSelectAll = () => {
    if (selectedSubtasks.length === parsedSubtasks.length) {
      setSelectedSubtasks([]);
    } else {
      setSelectedSubtasks(parsedSubtasks.map((_, index) => index));
    }
  };

  // 保存选中的子任务
  const handleSaveSubtasks = async () => {
    if (selectedSubtasks.length === 0) {
      alert('请至少选择一个子任务');
      return;
    }
    
    setSavingSubtasks(true);
    
    try {
      const token = localStorage.getItem('token');
      
      // 创建父任务
      const parentTaskData = {
        title: taskTitle,
        description: taskDescription,
        category: '拆分任务',
        tags: ['AI拆分'],
        priority: 3,
        estimatedPomodoros: Math.ceil(
          parsedSubtasks
            .filter((_, index) => selectedSubtasks.includes(index))
            .reduce((total, task) => {
              if (!task.estimatedTime) return total + 1;
              return total + (task.timeUnit === 'hour' ? 
                Math.ceil(task.estimatedTime * 2) : // 假设1小时=2个番茄钟
                Math.ceil(task.estimatedTime / 30)); // 假设30分钟=1个番茄钟
            }, 0)
        )
      };
      
      const parentRes = await axios.post('/api/tasks', parentTaskData, {
        headers: {
          'x-auth-token': token,
          'Content-Type': 'application/json'
        }
      });
      
      dispatch(addTask(parentRes.data));
      
      // 创建子任务
      const selectedTasks = parsedSubtasks.filter((_, index) => selectedSubtasks.includes(index));
      
      for (const task of selectedTasks) {
        const subtaskData = {
          title: task.title,
          parentTaskId: parentRes.data._id,
          category: '拆分子任务',
          tags: ['AI拆分'],
          priority: 3,
          estimatedPomodoros: task.estimatedTime ? 
            (task.timeUnit === 'hour' ? 
              Math.ceil(task.estimatedTime * 2) : // 假设1小时=2个番茄钟
              Math.ceil(task.estimatedTime / 30)) : // 假设30分钟=1个番茄钟
            1
        };
        
        const subtaskRes = await axios.post('/api/tasks', subtaskData, {
          headers: {
            'x-auth-token': token,
            'Content-Type': 'application/json'
          }
        });
        
        dispatch(addTask(subtaskRes.data));
      }
      
      alert('任务已成功保存！');
      
      // 重置表单
      setTaskTitle('');
      setTaskDescription('');
      setAdditionalContext('');
      setBreakdownResult(null);
      setParsedSubtasks([]);
      setSelectedSubtasks([]);
    } catch (err) {
      alert('保存任务失败: ' + (err.response?.data?.msg || err.message));
    } finally {
      setSavingSubtasks(false);
    }
  };

  return (
    <div className="ai-task-breakdown">
      <h3>AI任务拆分</h3>
      
      {!isConfigured ? (
        <div className="ai-not-configured">
          <p>您尚未配置AI设置。请先在设置页面配置AI提供商和API密钥。</p>
          <button 
            onClick={() => window.location.href = '/settings'}
            className="btn btn-primary"
          >
            前往设置
          </button>
        </div>
      ) : (
        <div className="task-breakdown-container">
          <div className="task-input-section">
            <div className="form-group">
              <label>任务标题</label>
              <input
                type="text"
                value={taskTitle}
                onChange={handleTaskTitleChange}
                className="form-control"
                placeholder="输入要拆分的任务标题"
              />
            </div>
            
            <div className="form-group">
              <label>任务描述 (可选)</label>
              <textarea
                value={taskDescription}
                onChange={handleTaskDescriptionChange}
                className="form-control"
                rows="3"
                placeholder="输入任务的详细描述"
              />
            </div>
            
            <div className="form-group">
              <label>附加上下文 (可选)</label>
              <textarea
                value={additionalContext}
                onChange={handleAdditionalContextChange}
                className="form-control"
                rows="2"
                placeholder="输入任何附加信息，如截止日期、资源限制等"
              />
            </div>
            
            <button 
              onClick={handleBreakdownTask}
              className="btn btn-primary"
              disabled={loading || !taskTitle.trim()}
            >
              {loading ? '处理中...' : '拆分任务'}
            </button>
          </div>
          
          {error && <div className="alert alert-danger">{error}</div>}
          
          {breakdownResult && (
            <div className="breakdown-result-section">
              <h4>AI拆分结果</h4>
              
              <div className="raw-result">
                <pre>{breakdownResult}</pre>
              </div>
              
              {parsedSubtasks.length > 0 && (
                <div className="parsed-subtasks">
                  <div className="subtasks-header">
                    <h5>识别到的子任务</h5>
                    <button 
                      onClick={handleToggleSelectAll}
                      className="btn btn-sm btn-outline-secondary"
                    >
                      {selectedSubtasks.length === parsedSubtasks.length ? '取消全选' : '全选'}
                    </button>
                  </div>
                  
                  <ul className="subtasks-list">
                    {parsedSubtasks.map((task, index) => (
                      <li key={index} className="subtask-item">
                        <div className="form-check">
                          <input
                            type="checkbox"
                            id={`subtask-${index}`}
                            checked={selectedSubtasks.includes(index)}
                            onChange={() => handleSubtaskSelectionChange(index)}
                            className="form-check-input"
                          />
                          <label className="form-check-label" htmlFor={`subtask-${index}`}>
                            {task.title}
                            {task.estimatedTime && (
                              <span className="estimated-time">
                                ({task.estimatedTime} {task.timeUnit === 'hour' ? '小时' : '分钟'})
                              </span>
                            )}
                          </label>
                        </div>
                      </li>
                    ))}
                  </ul>
                  
                  <button 
                    onClick={handleSaveSubtasks}
                    className="btn btn-success"
                    disabled={savingSubtasks || selectedSubtasks.length === 0}
                  >
                    {savingSubtasks ? '保存中...' : '保存选中的子任务'}
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default AITaskBreakdown;
