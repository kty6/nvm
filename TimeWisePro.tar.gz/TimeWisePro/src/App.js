import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, Navigate } from 'react-router-dom';
import { Provider } from 'react-redux';
import store from './store';

// 导入组件
import ScheduleManager from './containers/ScheduleManager';
import TodoList from './containers/TodoList';
import PomodoroTimer from './containers/PomodoroTimer';
import Statistics from './containers/Statistics';
import AITaskBreakdown from './containers/AITaskBreakdown';
import AITimeManagement from './containers/AITimeManagement';
import AICustomPrompt from './containers/AICustomPrompt';
import AISettings from './containers/AISettings';
import Login from './containers/Login';
import Register from './containers/Register';
import Dashboard from './containers/Dashboard';
import Settings from './containers/Settings';

// 导入样式
import './App.css';

const App = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(!!localStorage.getItem('token'));
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // 处理登录
  const handleLogin = () => {
    setIsAuthenticated(true);
  };

  // 处理登出
  const handleLogout = () => {
    localStorage.removeItem('token');
    setIsAuthenticated(false);
  };

  // 切换侧边栏
  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  // 关闭侧边栏（用于移动设备上点击导航链接后）
  const closeSidebar = () => {
    if (window.innerWidth < 992) {
      setSidebarOpen(false);
    }
  };

  return (
    <Provider store={store}>
      <Router>
        <div className="app-container">
          {isAuthenticated ? (
            <>
              <header className="app-header">
                <div className="header-left">
                  <button className="sidebar-toggle" onClick={toggleSidebar}>
                    <i className="fas fa-bars"></i>
                  </button>
                  <h1 className="app-title">TimeWisePro</h1>
                </div>
                <div className="header-right">
                  <button className="logout-btn" onClick={handleLogout}>
                    退出登录
                  </button>
                </div>
              </header>

              <div className="app-content">
                <aside className={`app-sidebar ${sidebarOpen ? 'open' : ''}`}>
                  <nav className="sidebar-nav">
                    <div className="nav-section">
                      <h3 className="nav-section-title">核心功能</h3>
                      <ul className="nav-list">
                        <li className="nav-item">
                          <Link to="/dashboard" className="nav-link" onClick={closeSidebar}>
                            <i className="fas fa-home"></i> 仪表盘
                          </Link>
                        </li>
                        <li className="nav-item">
                          <Link to="/schedule" className="nav-link" onClick={closeSidebar}>
                            <i className="fas fa-calendar-alt"></i> 日程管理
                          </Link>
                        </li>
                        <li className="nav-item">
                          <Link to="/todo" className="nav-link" onClick={closeSidebar}>
                            <i className="fas fa-tasks"></i> 待办事项
                          </Link>
                        </li>
                        <li className="nav-item">
                          <Link to="/pomodoro" className="nav-link" onClick={closeSidebar}>
                            <i className="fas fa-clock"></i> 番茄钟
                          </Link>
                        </li>
                      </ul>
                    </div>

                    <div className="nav-section">
                      <h3 className="nav-section-title">统计与分析</h3>
                      <ul className="nav-list">
                        <li className="nav-item">
                          <Link to="/statistics" className="nav-link" onClick={closeSidebar}>
                            <i className="fas fa-chart-bar"></i> 时间统计
                          </Link>
                        </li>
                      </ul>
                    </div>

                    <div className="nav-section">
                      <h3 className="nav-section-title">AI功能</h3>
                      <ul className="nav-list">
                        <li className="nav-item">
                          <Link to="/ai/task-breakdown" className="nav-link" onClick={closeSidebar}>
                            <i className="fas fa-project-diagram"></i> 任务拆分
                          </Link>
                        </li>
                        <li className="nav-item">
                          <Link to="/ai/time-management" className="nav-link" onClick={closeSidebar}>
                            <i className="fas fa-brain"></i> 时间管理分析
                          </Link>
                        </li>
                        <li className="nav-item">
                          <Link to="/ai/custom-prompt" className="nav-link" onClick={closeSidebar}>
                            <i className="fas fa-comment-dots"></i> 自定义提示词
                          </Link>
                        </li>
                      </ul>
                    </div>

                    <div className="nav-section">
                      <h3 className="nav-section-title">设置</h3>
                      <ul className="nav-list">
                        <li className="nav-item">
                          <Link to="/settings" className="nav-link" onClick={closeSidebar}>
                            <i className="fas fa-cog"></i> 个人设置
                          </Link>
                        </li>
                        <li className="nav-item">
                          <Link to="/ai/settings" className="nav-link" onClick={closeSidebar}>
                            <i className="fas fa-robot"></i> AI设置
                          </Link>
                        </li>
                      </ul>
                    </div>
                  </nav>
                </aside>

                <main className="app-main">
                  <Routes>
                    <Route path="/" element={<Navigate to="/dashboard" />} />
                    <Route path="/dashboard" element={<Dashboard />} />
                    <Route path="/schedule" element={<ScheduleManager />} />
                    <Route path="/todo" element={<TodoList />} />
                    <Route path="/pomodoro" element={<PomodoroTimer />} />
                    <Route path="/statistics" element={<Statistics />} />
                    <Route path="/ai/task-breakdown" element={<AITaskBreakdown />} />
                    <Route path="/ai/time-management" element={<AITimeManagement />} />
                    <Route path="/ai/custom-prompt" element={<AICustomPrompt />} />
                    <Route path="/ai/settings" element={<AISettings />} />
                    <Route path="/settings" element={<Settings />} />
                  </Routes>
                </main>
              </div>

              {sidebarOpen && (
                <div className="sidebar-backdrop" onClick={toggleSidebar}></div>
              )}
            </>
          ) : (
            <div className="auth-container">
              <Routes>
                <Route path="/login" element={<Login onLogin={handleLogin} />} />
                <Route path="/register" element={<Register onLogin={handleLogin} />} />
                <Route path="*" element={<Navigate to="/login" />} />
              </Routes>
            </div>
          )}
        </div>
      </Router>
    </Provider>
  );
};

export default App;
