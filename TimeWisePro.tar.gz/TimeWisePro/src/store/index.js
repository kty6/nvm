import { configureStore } from '@reduxjs/toolkit';
import scheduleReducer from './slices/scheduleSlice';
import todoReducer from './slices/todoSlice';
import pomodoroReducer from './slices/pomodoroSlice';
import statisticsReducer from './slices/statisticsSlice';
import aiReducer from './slices/aiSlice';
import userReducer from './slices/userSlice';

const store = configureStore({
  reducer: {
    schedule: scheduleReducer,
    todo: todoReducer,
    pomodoro: pomodoroReducer,
    statistics: statisticsReducer,
    ai: aiReducer,
    user: userReducer
  }
});

export default store;
