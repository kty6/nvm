import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  isActive: false,
  workDuration: 25 * 60, // 25分钟，以秒为单位
  breakDuration: 5 * 60, // 5分钟，以秒为单位
  longBreakDuration: 15 * 60, // 15分钟，以秒为单位
  currentSession: 'work', // 'work' 或 'break'
  timeRemaining: 25 * 60,
  completedPomodoros: 0,
  sessionsUntilLongBreak: 4,
  currentSessionCount: 0,
  history: [],
  currentTaskId: null
};

const pomodoroSlice = createSlice({
  name: 'pomodoro',
  initialState,
  reducers: {
    startTimer(state) {
      state.isActive = true;
    },
    pauseTimer(state) {
      state.isActive = false;
    },
    resetTimer(state) {
      state.timeRemaining = state.currentSession === 'work' ? state.workDuration : 
        (state.currentSessionCount % state.sessionsUntilLongBreak === 0 ? state.longBreakDuration : state.breakDuration);
      state.isActive = false;
    },
    tickTimer(state) {
      if (state.isActive && state.timeRemaining > 0) {
        state.timeRemaining -= 1;
      }
    },
    completeSession(state, action) {
      if (state.currentSession === 'work') {
        state.completedPomodoros += 1;
        state.currentSessionCount += 1;
        state.currentSession = 'break';
        state.timeRemaining = state.currentSessionCount % state.sessionsUntilLongBreak === 0 ? 
          state.longBreakDuration : state.breakDuration;
        
        // 记录完成的番茄钟
        state.history.push({
          id: Date.now().toString(),
          taskId: state.currentTaskId,
          startTime: new Date(Date.now() - state.workDuration * 1000).toISOString(),
          endTime: new Date().toISOString(),
          duration: state.workDuration,
          type: 'work',
          interrupted: action.payload?.interrupted || false
        });
      } else {
        state.currentSession = 'work';
        state.timeRemaining = state.workDuration;
        
        // 记录完成的休息时间
        state.history.push({
          id: Date.now().toString(),
          startTime: new Date(Date.now() - (state.currentSessionCount % state.sessionsUntilLongBreak === 0 ? 
            state.longBreakDuration : state.breakDuration) * 1000).toISOString(),
          endTime: new Date().toISOString(),
          duration: state.currentSessionCount % state.sessionsUntilLongBreak === 0 ? 
            state.longBreakDuration : state.breakDuration,
          type: 'break',
          interrupted: action.payload?.interrupted || false
        });
      }
    },
    setWorkDuration(state, action) {
      state.workDuration = action.payload * 60;
      if (state.currentSession === 'work') {
        state.timeRemaining = state.workDuration;
      }
    },
    setBreakDuration(state, action) {
      state.breakDuration = action.payload * 60;
      if (state.currentSession === 'break' && state.currentSessionCount % state.sessionsUntilLongBreak !== 0) {
        state.timeRemaining = state.breakDuration;
      }
    },
    setLongBreakDuration(state, action) {
      state.longBreakDuration = action.payload * 60;
      if (state.currentSession === 'break' && state.currentSessionCount % state.sessionsUntilLongBreak === 0) {
        state.timeRemaining = state.longBreakDuration;
      }
    },
    setCurrentTaskId(state, action) {
      state.currentTaskId = action.payload;
    }
  }
});

export const {
  startTimer,
  pauseTimer,
  resetTimer,
  tickTimer,
  completeSession,
  setWorkDuration,
  setBreakDuration,
  setLongBreakDuration,
  setCurrentTaskId
} = pomodoroSlice.actions;

export default pomodoroSlice.reducer;
