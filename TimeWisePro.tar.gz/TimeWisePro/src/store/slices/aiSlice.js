import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  provider: 'openai', // 默认AI提供商
  apiEndpoint: 'https://api.openai.com/v1/chat/completions', // 默认API端点
  apiKey: '',
  isConfigured: false,
  loading: false,
  error: null,
  taskBreakdownPrompt: '请将以下任务拆分为更小的子任务，并为每个子任务提供时间估计：',
  timeManagementPrompt: '请根据我的日程和任务列表，提供时间管理优化建议：',
  prioritizationPrompt: '请帮我对以下任务进行优先级排序：',
  customPrompts: {},
  lastResponse: null
};

const aiSlice = createSlice({
  name: 'ai',
  initialState,
  reducers: {
    setProvider(state, action) {
      state.provider = action.payload;
    },
    setApiEndpoint(state, action) {
      state.apiEndpoint = action.payload;
    },
    setApiKey(state, action) {
      state.apiKey = action.payload;
      state.isConfigured = !!action.payload;
    },
    setTaskBreakdownPrompt(state, action) {
      state.taskBreakdownPrompt = action.payload;
    },
    setTimeManagementPrompt(state, action) {
      state.timeManagementPrompt = action.payload;
    },
    setPrioritizationPrompt(state, action) {
      state.prioritizationPrompt = action.payload;
    },
    addCustomPrompt(state, action) {
      state.customPrompts[action.payload.name] = action.payload.prompt;
    },
    removeCustomPrompt(state, action) {
      delete state.customPrompts[action.payload];
    },
    aiRequestStart(state) {
      state.loading = true;
      state.error = null;
    },
    aiRequestSuccess(state, action) {
      state.loading = false;
      state.lastResponse = action.payload;
    },
    aiRequestFailure(state, action) {
      state.loading = false;
      state.error = action.payload;
    }
  }
});

export const {
  setProvider,
  setApiEndpoint,
  setApiKey,
  setTaskBreakdownPrompt,
  setTimeManagementPrompt,
  setPrioritizationPrompt,
  addCustomPrompt,
  removeCustomPrompt,
  aiRequestStart,
  aiRequestSuccess,
  aiRequestFailure
} = aiSlice.actions;

export default aiSlice.reducer;
