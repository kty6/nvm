import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  statistics: [],
  dailyStats: null,
  weeklyStats: null,
  monthlyStats: null,
  loading: false,
  error: null
};

const statisticsSlice = createSlice({
  name: 'statistics',
  initialState,
  reducers: {
    fetchStatisticsStart(state) {
      state.loading = true;
      state.error = null;
    },
    fetchStatisticsSuccess(state, action) {
      state.statistics = action.payload;
      state.loading = false;
    },
    fetchStatisticsFailure(state, action) {
      state.loading = false;
      state.error = action.payload;
    },
    fetchDailyStatsSuccess(state, action) {
      state.dailyStats = action.payload;
    },
    fetchWeeklyStatsSuccess(state, action) {
      state.weeklyStats = action.payload;
    },
    fetchMonthlyStatsSuccess(state, action) {
      state.monthlyStats = action.payload;
    },
    addStatistic(state, action) {
      state.statistics.push(action.payload);
    },
    updateStatistic(state, action) {
      const index = state.statistics.findIndex(stat => stat.id === action.payload.id);
      if (index !== -1) {
        state.statistics[index] = action.payload;
      }
    }
  }
});

export const {
  fetchStatisticsStart,
  fetchStatisticsSuccess,
  fetchStatisticsFailure,
  fetchDailyStatsSuccess,
  fetchWeeklyStatsSuccess,
  fetchMonthlyStatsSuccess,
  addStatistic,
  updateStatistic
} = statisticsSlice.actions;

export default statisticsSlice.reducer;
