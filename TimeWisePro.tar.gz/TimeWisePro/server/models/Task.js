const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const TaskSchema = new Schema({
  userId: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  title: {
    type: String,
    required: true
  },
  description: {
    type: String,
    default: ''
  },
  dueDate: {
    type: Date
  },
  completed: {
    type: Boolean,
    default: false
  },
  completedAt: {
    type: Date
  },
  parentTaskId: {
    type: Schema.Types.ObjectId,
    ref: 'Task'
  },
  category: {
    type: String,
    default: '默认'
  },
  tags: [{
    type: String
  }],
  priority: {
    type: Number,
    min: 1,
    max: 5,
    default: 3
  },
  estimatedPomodoros: {
    type: Number,
    default: 1
  },
  actualPomodoros: {
    type: Number,
    default: 0
  },
  order: {
    type: Number,
    default: 0
  }
}, { timestamps: true });

module.exports = mongoose.model('Task', TaskSchema);
