const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const PomodoroSchema = new Schema({
  userId: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  taskId: {
    type: Schema.Types.ObjectId,
    ref: 'Task'
  },
  startTime: {
    type: Date,
    required: true
  },
  endTime: {
    type: Date,
    required: true
  },
  duration: {
    type: Number,
    required: true // 以分钟为单位
  },
  type: {
    type: String,
    enum: ['work', 'break'],
    required: true
  },
  completed: {
    type: Boolean,
    default: true
  },
  interrupted: {
    type: Boolean,
    default: false
  },
  interruptionReason: {
    type: String
  }
}, { timestamps: true });

module.exports = mongoose.model('Pomodoro', PomodoroSchema);
