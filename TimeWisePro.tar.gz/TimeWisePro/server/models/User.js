const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const UserSchema = new Schema({
  username: {
    type: String,
    required: true,
    unique: true
  },
  email: {
    type: String,
    required: true,
    unique: true
  },
  password: {
    type: String,
    required: true
  },
  settings: {
    theme: {
      type: String,
      default: 'light'
    },
    notifications: {
      type: Boolean,
      default: true
    },
    aiProvider: {
      type: String,
      default: 'openai'
    },
    apiEndpoint: {
      type: String,
      default: 'https://api.openai.com/v1/chat/completions'
    },
    apiKey: {
      type: String,
      default: ''
    }
  }
}, { timestamps: true });

module.exports = mongoose.model('User', UserSchema);
