const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const StatisticSchema = new Schema({
  userId: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  date: {
    type: Date,
    required: true
  },
  completedTasks: {
    type: Number,
    default: 0
  },
  totalTasks: {
    type: Number,
    default: 0
  },
  completedPomodoros: {
    type: Number,
    default: 0
  },
  totalWorkTime: {
    type: Number,
    default: 0 // 以分钟为单位
  },
  productivityScore: {
    type: Number,
    default: 0
  },
  categories: [{
    name: {
      type: String,
      required: true
    },
    timeSpent: {
      type: Number,
      required: true // 以分钟为单位
    }
  }]
}, { timestamps: true });

module.exports = mongoose.model('Statistic', StatisticSchema);
