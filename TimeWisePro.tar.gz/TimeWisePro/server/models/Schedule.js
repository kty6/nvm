const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const ScheduleSchema = new Schema({
  userId: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  title: {
    type: String,
    required: true
  },
  description: {
    type: String,
    default: ''
  },
  startTime: {
    type: Date,
    required: true
  },
  endTime: {
    type: Date,
    required: true
  },
  location: {
    type: String,
    default: ''
  },
  isAllDay: {
    type: Boolean,
    default: false
  },
  recurrence: {
    type: {
      type: String,
      enum: ['none', 'daily', 'weekly', 'monthly', 'yearly'],
      default: 'none'
    },
    interval: {
      type: Number,
      default: 1
    },
    endDate: {
      type: Date
    }
  },
  reminder: {
    enabled: {
      type: Boolean,
      default: false
    },
    time: {
      type: Number,
      default: 15 // 默认提前15分钟提醒
    }
  },
  category: {
    type: String,
    default: '默认'
  },
  tags: [{
    type: String
  }],
  priority: {
    type: Number,
    min: 1,
    max: 5,
    default: 3
  }
}, { timestamps: true });

module.exports = mongoose.model('Schedule', ScheduleSchema);
