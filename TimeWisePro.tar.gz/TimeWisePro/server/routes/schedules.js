const express = require('express');
const router = express.Router();
const Schedule = require('../models/Schedule');
const auth = require('../middleware/auth');

// @route   GET api/schedules
// @desc    获取用户所有日程
// @access  Private
router.get('/', auth, async (req, res) => {
  try {
    const schedules = await Schedule.find({ userId: req.user.id }).sort({ startTime: 1 });
    res.json(schedules);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('服务器错误');
  }
});

// @route   POST api/schedules
// @desc    创建新日程
// @access  Private
router.post('/', auth, async (req, res) => {
  const {
    title,
    description,
    startTime,
    endTime,
    location,
    isAllDay,
    recurrence,
    reminder,
    category,
    tags,
    priority
  } = req.body;

  try {
    const newSchedule = new Schedule({
      userId: req.user.id,
      title,
      description,
      startTime,
      endTime,
      location,
      isAllDay,
      recurrence,
      reminder,
      category,
      tags,
      priority
    });

    const schedule = await newSchedule.save();
    res.json(schedule);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('服务器错误');
  }
});

// @route   GET api/schedules/:id
// @desc    获取指定日程
// @access  Private
router.get('/:id', auth, async (req, res) => {
  try {
    const schedule = await Schedule.findById(req.params.id);

    if (!schedule) {
      return res.status(404).json({ msg: '日程不存在' });
    }

    // 确保用户只能访问自己的日程
    if (schedule.userId.toString() !== req.user.id) {
      return res.status(401).json({ msg: '无访问权限' });
    }

    res.json(schedule);
  } catch (err) {
    console.error(err.message);
    if (err.kind === 'ObjectId') {
      return res.status(404).json({ msg: '日程不存在' });
    }
    res.status(500).send('服务器错误');
  }
});

// @route   PUT api/schedules/:id
// @desc    更新日程
// @access  Private
router.put('/:id', auth, async (req, res) => {
  const {
    title,
    description,
    startTime,
    endTime,
    location,
    isAllDay,
    recurrence,
    reminder,
    category,
    tags,
    priority
  } = req.body;

  try {
    let schedule = await Schedule.findById(req.params.id);

    if (!schedule) {
      return res.status(404).json({ msg: '日程不存在' });
    }

    // 确保用户只能更新自己的日程
    if (schedule.userId.toString() !== req.user.id) {
      return res.status(401).json({ msg: '无访问权限' });
    }

    // 更新日程
    if (title) schedule.title = title;
    if (description !== undefined) schedule.description = description;
    if (startTime) schedule.startTime = startTime;
    if (endTime) schedule.endTime = endTime;
    if (location !== undefined) schedule.location = location;
    if (isAllDay !== undefined) schedule.isAllDay = isAllDay;
    if (recurrence) schedule.recurrence = recurrence;
    if (reminder) schedule.reminder = reminder;
    if (category) schedule.category = category;
    if (tags) schedule.tags = tags;
    if (priority) schedule.priority = priority;

    await schedule.save();
    res.json(schedule);
  } catch (err) {
    console.error(err.message);
    if (err.kind === 'ObjectId') {
      return res.status(404).json({ msg: '日程不存在' });
    }
    res.status(500).send('服务器错误');
  }
});

// @route   DELETE api/schedules/:id
// @desc    删除日程
// @access  Private
router.delete('/:id', auth, async (req, res) => {
  try {
    const schedule = await Schedule.findById(req.params.id);

    if (!schedule) {
      return res.status(404).json({ msg: '日程不存在' });
    }

    // 确保用户只能删除自己的日程
    if (schedule.userId.toString() !== req.user.id) {
      return res.status(401).json({ msg: '无访问权限' });
    }

    await schedule.remove();
    res.json({ msg: '日程已删除' });
  } catch (err) {
    console.error(err.message);
    if (err.kind === 'ObjectId') {
      return res.status(404).json({ msg: '日程不存在' });
    }
    res.status(500).send('服务器错误');
  }
});

// @route   GET api/schedules/date/:date
// @desc    获取指定日期的日程
// @access  Private
router.get('/date/:date', auth, async (req, res) => {
  try {
    const date = new Date(req.params.date);
    const nextDate = new Date(date);
    nextDate.setDate(date.getDate() + 1);

    const schedules = await Schedule.find({
      userId: req.user.id,
      $or: [
        { startTime: { $gte: date, $lt: nextDate } },
        { endTime: { $gte: date, $lt: nextDate } },
        {
          startTime: { $lt: date },
          endTime: { $gt: nextDate }
        }
      ]
    }).sort({ startTime: 1 });

    res.json(schedules);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('服务器错误');
  }
});

module.exports = router;
