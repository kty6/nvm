const express = require('express');
const router = express.Router();
const Pomodoro = require('../models/Pomodoro');
const Task = require('../models/Task');
const auth = require('../middleware/auth');

// @route   GET api/pomodoros
// @desc    获取用户所有番茄钟记录
// @access  Private
router.get('/', auth, async (req, res) => {
  try {
    const pomodoros = await Pomodoro.find({ userId: req.user.id }).sort({ startTime: -1 });
    res.json(pomodoros);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('服务器错误');
  }
});

// @route   POST api/pomodoros
// @desc    创建新番茄钟记录
// @access  Private
router.post('/', auth, async (req, res) => {
  const {
    taskId,
    startTime,
    endTime,
    duration,
    type,
    completed,
    interrupted,
    interruptionReason
  } = req.body;

  try {
    const newPomodoro = new Pomodoro({
      userId: req.user.id,
      taskId,
      startTime,
      endTime,
      duration,
      type,
      completed,
      interrupted,
      interruptionReason
    });

    const pomodoro = await newPomodoro.save();

    // 如果番茄钟与任务关联且已完成，更新任务的实际番茄钟数量
    if (taskId && completed && !interrupted && type === 'work') {
      const task = await Task.findById(taskId);
      if (task && task.userId.toString() === req.user.id) {
        task.actualPomodoros += 1;
        await task.save();
      }
    }

    res.json(pomodoro);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('服务器错误');
  }
});

// @route   GET api/pomodoros/:id
// @desc    获取指定番茄钟记录
// @access  Private
router.get('/:id', auth, async (req, res) => {
  try {
    const pomodoro = await Pomodoro.findById(req.params.id);

    if (!pomodoro) {
      return res.status(404).json({ msg: '番茄钟记录不存在' });
    }

    // 确保用户只能访问自己的番茄钟记录
    if (pomodoro.userId.toString() !== req.user.id) {
      return res.status(401).json({ msg: '无访问权限' });
    }

    res.json(pomodoro);
  } catch (err) {
    console.error(err.message);
    if (err.kind === 'ObjectId') {
      return res.status(404).json({ msg: '番茄钟记录不存在' });
    }
    res.status(500).send('服务器错误');
  }
});

// @route   PUT api/pomodoros/:id
// @desc    更新番茄钟记录
// @access  Private
router.put('/:id', auth, async (req, res) => {
  const {
    taskId,
    startTime,
    endTime,
    duration,
    type,
    completed,
    interrupted,
    interruptionReason
  } = req.body;

  try {
    let pomodoro = await Pomodoro.findById(req.params.id);

    if (!pomodoro) {
      return res.status(404).json({ msg: '番茄钟记录不存在' });
    }

    // 确保用户只能更新自己的番茄钟记录
    if (pomodoro.userId.toString() !== req.user.id) {
      return res.status(401).json({ msg: '无访问权限' });
    }

    // 如果之前与任务关联且已完成，但现在被标记为中断或未完成，需要减少任务的实际番茄钟数量
    if (pomodoro.taskId && pomodoro.completed && !pomodoro.interrupted && pomodoro.type === 'work' &&
        (interrupted || !completed || type !== 'work')) {
      const oldTask = await Task.findById(pomodoro.taskId);
      if (oldTask && oldTask.userId.toString() === req.user.id && oldTask.actualPomodoros > 0) {
        oldTask.actualPomodoros -= 1;
        await oldTask.save();
      }
    }

    // 更新番茄钟记录
    if (taskId !== undefined) pomodoro.taskId = taskId;
    if (startTime) pomodoro.startTime = startTime;
    if (endTime) pomodoro.endTime = endTime;
    if (duration) pomodoro.duration = duration;
    if (type) pomodoro.type = type;
    if (completed !== undefined) pomodoro.completed = completed;
    if (interrupted !== undefined) pomodoro.interrupted = interrupted;
    if (interruptionReason !== undefined) pomodoro.interruptionReason = interruptionReason;

    await pomodoro.save();

    // 如果现在与任务关联且已完成，需要增加任务的实际番茄钟数量
    if (pomodoro.taskId && pomodoro.completed && !pomodoro.interrupted && pomodoro.type === 'work') {
      const newTask = await Task.findById(pomodoro.taskId);
      if (newTask && newTask.userId.toString() === req.user.id) {
        newTask.actualPomodoros += 1;
        await newTask.save();
      }
    }

    res.json(pomodoro);
  } catch (err) {
    console.error(err.message);
    if (err.kind === 'ObjectId') {
      return res.status(404).json({ msg: '番茄钟记录不存在' });
    }
    res.status(500).send('服务器错误');
  }
});

// @route   DELETE api/pomodoros/:id
// @desc    删除番茄钟记录
// @access  Private
router.delete('/:id', auth, async (req, res) => {
  try {
    const pomodoro = await Pomodoro.findById(req.params.id);

    if (!pomodoro) {
      return res.status(404).json({ msg: '番茄钟记录不存在' });
    }

    // 确保用户只能删除自己的番茄钟记录
    if (pomodoro.userId.toString() !== req.user.id) {
      return res.status(401).json({ msg: '无访问权限' });
    }

    // 如果番茄钟与任务关联且已完成，需要减少任务的实际番茄钟数量
    if (pomodoro.taskId && pomodoro.completed && !pomodoro.interrupted && pomodoro.type === 'work') {
      const task = await Task.findById(pomodoro.taskId);
      if (task && task.userId.toString() === req.user.id && task.actualPomodoros > 0) {
        task.actualPomodoros -= 1;
        await task.save();
      }
    }

    await pomodoro.remove();
    res.json({ msg: '番茄钟记录已删除' });
  } catch (err) {
    console.error(err.message);
    if (err.kind === 'ObjectId') {
      return res.status(404).json({ msg: '番茄钟记录不存在' });
    }
    res.status(500).send('服务器错误');
  }
});

// @route   GET api/pomodoros/task/:taskId
// @desc    获取指定任务的番茄钟记录
// @access  Private
router.get('/task/:taskId', auth, async (req, res) => {
  try {
    const pomodoros = await Pomodoro.find({
      userId: req.user.id,
      taskId: req.params.taskId
    }).sort({ startTime: -1 });
    
    res.json(pomodoros);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('服务器错误');
  }
});

// @route   GET api/pomodoros/date/:date
// @desc    获取指定日期的番茄钟记录
// @access  Private
router.get('/date/:date', auth, async (req, res) => {
  try {
    const date = new Date(req.params.date);
    const nextDate = new Date(date);
    nextDate.setDate(date.getDate() + 1);

    const pomodoros = await Pomodoro.find({
      userId: req.user.id,
      startTime: { $gte: date, $lt: nextDate }
    }).sort({ startTime: 1 });

    res.json(pomodoros);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('服务器错误');
  }
});

module.exports = router;
