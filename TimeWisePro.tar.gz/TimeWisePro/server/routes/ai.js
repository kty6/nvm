const express = require('express');
const router = express.Router();
const axios = require('axios');
const auth = require('../middleware/auth');
const User = require('../models/User');

// @route   POST api/ai/task-breakdown
// @desc    使用AI拆分任务
// @access  Private
router.post('/task-breakdown', auth, async (req, res) => {
  try {
    const { task, additionalContext } = req.body;
    
    // 获取用户AI配置
    const user = await User.findById(req.user.id);
    if (!user) {
      return res.status(404).json({ msg: '用户不存在' });
    }
    
    const { aiProvider, apiEndpoint, apiKey } = user.settings;
    
    if (!apiKey) {
      return res.status(400).json({ msg: '未配置AI API密钥' });
    }
    
    // 构建提示词
    let prompt = `请将以下任务拆分为更小的子任务，并为每个子任务提供时间估计：\n\n任务：${task}`;
    
    if (additionalContext) {
      prompt += `\n\n额外上下文：${additionalContext}`;
    }
    
    // 根据不同的AI提供商发送请求
    let response;
    
    if (aiProvider === 'openai') {
      response = await axios.post(
        apiEndpoint,
        {
          model: 'gpt-3.5-turbo',
          messages: [{ role: 'user', content: prompt }],
          temperature: 0.7
        },
        {
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiKey}`
          }
        }
      );
      
      res.json({ 
        result: response.data.choices[0].message.content,
        provider: aiProvider
      });
    } else if (aiProvider === 'anthropic') {
      response = await axios.post(
        apiEndpoint,
        {
          model: 'claude-2',
          prompt: `\n\nHuman: ${prompt}\n\nAssistant:`,
          max_tokens_to_sample: 1000
        },
        {
          headers: {
            'Content-Type': 'application/json',
            'x-api-key': apiKey
          }
        }
      );
      
      res.json({ 
        result: response.data.completion,
        provider: aiProvider
      });
    } else {
      // 自定义API提供商
      try {
        response = await axios.post(
          apiEndpoint,
          { prompt },
          {
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${apiKey}`
            }
          }
        );
        
        res.json({ 
          result: response.data.result || response.data.text || response.data.content || response.data,
          provider: 'custom'
        });
      } catch (error) {
        console.error('自定义AI API请求错误:', error);
        return res.status(500).json({ msg: '自定义AI API请求失败', error: error.message });
      }
    }
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ msg: '服务器错误', error: err.message });
  }
});

// @route   POST api/ai/time-management
// @desc    获取时间管理建议
// @access  Private
router.post('/time-management', auth, async (req, res) => {
  try {
    const { schedules, tasks, statistics, additionalContext } = req.body;
    
    // 获取用户AI配置
    const user = await User.findById(req.user.id);
    if (!user) {
      return res.status(404).json({ msg: '用户不存在' });
    }
    
    const { aiProvider, apiEndpoint, apiKey } = user.settings;
    
    if (!apiKey) {
      return res.status(400).json({ msg: '未配置AI API密钥' });
    }
    
    // 构建提示词
    let prompt = `请根据我的日程和任务列表，提供时间管理优化建议：\n\n`;
    
    if (schedules && schedules.length > 0) {
      prompt += `日程：\n${JSON.stringify(schedules, null, 2)}\n\n`;
    }
    
    if (tasks && tasks.length > 0) {
      prompt += `任务：\n${JSON.stringify(tasks, null, 2)}\n\n`;
    }
    
    if (statistics) {
      prompt += `统计数据：\n${JSON.stringify(statistics, null, 2)}\n\n`;
    }
    
    if (additionalContext) {
      prompt += `额外上下文：${additionalContext}\n\n`;
    }
    
    // 根据不同的AI提供商发送请求
    let response;
    
    if (aiProvider === 'openai') {
      response = await axios.post(
        apiEndpoint,
        {
          model: 'gpt-3.5-turbo',
          messages: [{ role: 'user', content: prompt }],
          temperature: 0.7
        },
        {
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiKey}`
          }
        }
      );
      
      res.json({ 
        result: response.data.choices[0].message.content,
        provider: aiProvider
      });
    } else if (aiProvider === 'anthropic') {
      response = await axios.post(
        apiEndpoint,
        {
          model: 'claude-2',
          prompt: `\n\nHuman: ${prompt}\n\nAssistant:`,
          max_tokens_to_sample: 1000
        },
        {
          headers: {
            'Content-Type': 'application/json',
            'x-api-key': apiKey
          }
        }
      );
      
      res.json({ 
        result: response.data.completion,
        provider: aiProvider
      });
    } else {
      // 自定义API提供商
      try {
        response = await axios.post(
          apiEndpoint,
          { prompt },
          {
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${apiKey}`
            }
          }
        );
        
        res.json({ 
          result: response.data.result || response.data.text || response.data.content || response.data,
          provider: 'custom'
        });
      } catch (error) {
        console.error('自定义AI API请求错误:', error);
        return res.status(500).json({ msg: '自定义AI API请求失败', error: error.message });
      }
    }
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ msg: '服务器错误', error: err.message });
  }
});

// @route   POST api/ai/custom-prompt
// @desc    发送自定义提示词到AI
// @access  Private
router.post('/custom-prompt', auth, async (req, res) => {
  try {
    const { prompt } = req.body;
    
    // 获取用户AI配置
    const user = await User.findById(req.user.id);
    if (!user) {
      return res.status(404).json({ msg: '用户不存在' });
    }
    
    const { aiProvider, apiEndpoint, apiKey } = user.settings;
    
    if (!apiKey) {
      return res.status(400).json({ msg: '未配置AI API密钥' });
    }
    
    // 根据不同的AI提供商发送请求
    let response;
    
    if (aiProvider === 'openai') {
      response = await axios.post(
        apiEndpoint,
        {
          model: 'gpt-3.5-turbo',
          messages: [{ role: 'user', content: prompt }],
          temperature: 0.7
        },
        {
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiKey}`
          }
        }
      );
      
      res.json({ 
        result: response.data.choices[0].message.content,
        provider: aiProvider
      });
    } else if (aiProvider === 'anthropic') {
      response = await axios.post(
        apiEndpoint,
        {
          model: 'claude-2',
          prompt: `\n\nHuman: ${prompt}\n\nAssistant:`,
          max_tokens_to_sample: 1000
        },
        {
          headers: {
            'Content-Type': 'application/json',
            'x-api-key': apiKey
          }
        }
      );
      
      res.json({ 
        result: response.data.completion,
        provider: aiProvider
      });
    } else {
      // 自定义API提供商
      try {
        response = await axios.post(
          apiEndpoint,
          { prompt },
          {
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${apiKey}`
            }
          }
        );
        
        res.json({ 
          result: response.data.result || response.data.text || response.data.content || response.data,
          provider: 'custom'
        });
      } catch (error) {
        console.error('自定义AI API请求错误:', error);
        return res.status(500).json({ msg: '自定义AI API请求失败', error: error.message });
      }
    }
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ msg: '服务器错误', error: err.message });
  }
});

module.exports = router;
