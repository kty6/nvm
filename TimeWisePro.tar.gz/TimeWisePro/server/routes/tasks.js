const express = require('express');
const router = express.Router();
const Task = require('../models/Task');
const auth = require('../middleware/auth');

// @route   GET api/tasks
// @desc    获取用户所有任务
// @access  Private
router.get('/', auth, async (req, res) => {
  try {
    const tasks = await Task.find({ userId: req.user.id }).sort({ order: 1, createdAt: -1 });
    res.json(tasks);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('服务器错误');
  }
});

// @route   POST api/tasks
// @desc    创建新任务
// @access  Private
router.post('/', auth, async (req, res) => {
  const {
    title,
    description,
    dueDate,
    parentTaskId,
    category,
    tags,
    priority,
    estimatedPomodoros,
    order
  } = req.body;

  try {
    // 获取最大的order值
    let maxOrder = 0;
    if (!order) {
      const lastTask = await Task.findOne({ userId: req.user.id }).sort({ order: -1 });
      if (lastTask) {
        maxOrder = lastTask.order + 1;
      }
    }

    const newTask = new Task({
      userId: req.user.id,
      title,
      description,
      dueDate,
      parentTaskId,
      category,
      tags,
      priority,
      estimatedPomodoros,
      order: order || maxOrder
    });

    const task = await newTask.save();
    res.json(task);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('服务器错误');
  }
});

// @route   GET api/tasks/:id
// @desc    获取指定任务
// @access  Private
router.get('/:id', auth, async (req, res) => {
  try {
    const task = await Task.findById(req.params.id);

    if (!task) {
      return res.status(404).json({ msg: '任务不存在' });
    }

    // 确保用户只能访问自己的任务
    if (task.userId.toString() !== req.user.id) {
      return res.status(401).json({ msg: '无访问权限' });
    }

    res.json(task);
  } catch (err) {
    console.error(err.message);
    if (err.kind === 'ObjectId') {
      return res.status(404).json({ msg: '任务不存在' });
    }
    res.status(500).send('服务器错误');
  }
});

// @route   PUT api/tasks/:id
// @desc    更新任务
// @access  Private
router.put('/:id', auth, async (req, res) => {
  const {
    title,
    description,
    dueDate,
    completed,
    completedAt,
    parentTaskId,
    category,
    tags,
    priority,
    estimatedPomodoros,
    actualPomodoros,
    order
  } = req.body;

  try {
    let task = await Task.findById(req.params.id);

    if (!task) {
      return res.status(404).json({ msg: '任务不存在' });
    }

    // 确保用户只能更新自己的任务
    if (task.userId.toString() !== req.user.id) {
      return res.status(401).json({ msg: '无访问权限' });
    }

    // 更新任务
    if (title) task.title = title;
    if (description !== undefined) task.description = description;
    if (dueDate !== undefined) task.dueDate = dueDate;
    if (completed !== undefined) {
      task.completed = completed;
      if (completed && !task.completed) {
        task.completedAt = new Date();
      } else if (!completed) {
        task.completedAt = null;
      }
    }
    if (completedAt) task.completedAt = completedAt;
    if (parentTaskId !== undefined) task.parentTaskId = parentTaskId;
    if (category) task.category = category;
    if (tags) task.tags = tags;
    if (priority) task.priority = priority;
    if (estimatedPomodoros) task.estimatedPomodoros = estimatedPomodoros;
    if (actualPomodoros !== undefined) task.actualPomodoros = actualPomodoros;
    if (order !== undefined) task.order = order;

    await task.save();
    res.json(task);
  } catch (err) {
    console.error(err.message);
    if (err.kind === 'ObjectId') {
      return res.status(404).json({ msg: '任务不存在' });
    }
    res.status(500).send('服务器错误');
  }
});

// @route   DELETE api/tasks/:id
// @desc    删除任务
// @access  Private
router.delete('/:id', auth, async (req, res) => {
  try {
    const task = await Task.findById(req.params.id);

    if (!task) {
      return res.status(404).json({ msg: '任务不存在' });
    }

    // 确保用户只能删除自己的任务
    if (task.userId.toString() !== req.user.id) {
      return res.status(401).json({ msg: '无访问权限' });
    }

    // 删除任务及其子任务
    await Task.deleteMany({ $or: [{ _id: req.params.id }, { parentTaskId: req.params.id }] });
    
    res.json({ msg: '任务已删除' });
  } catch (err) {
    console.error(err.message);
    if (err.kind === 'ObjectId') {
      return res.status(404).json({ msg: '任务不存在' });
    }
    res.status(500).send('服务器错误');
  }
});

// @route   PUT api/tasks/:id/toggle
// @desc    切换任务完成状态
// @access  Private
router.put('/:id/toggle', auth, async (req, res) => {
  try {
    const task = await Task.findById(req.params.id);

    if (!task) {
      return res.status(404).json({ msg: '任务不存在' });
    }

    // 确保用户只能更新自己的任务
    if (task.userId.toString() !== req.user.id) {
      return res.status(401).json({ msg: '无访问权限' });
    }

    // 切换完成状态
    task.completed = !task.completed;
    task.completedAt = task.completed ? new Date() : null;

    await task.save();
    res.json(task);
  } catch (err) {
    console.error(err.message);
    if (err.kind === 'ObjectId') {
      return res.status(404).json({ msg: '任务不存在' });
    }
    res.status(500).send('服务器错误');
  }
});

// @route   GET api/tasks/subtasks/:parentId
// @desc    获取指定任务的子任务
// @access  Private
router.get('/subtasks/:parentId', auth, async (req, res) => {
  try {
    const tasks = await Task.find({ 
      userId: req.user.id,
      parentTaskId: req.params.parentId 
    }).sort({ order: 1 });
    
    res.json(tasks);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('服务器错误');
  }
});

module.exports = router;
