const express = require('express');
const router = express.Router();
const Statistic = require('../models/Statistic');
const Pomodoro = require('../models/Pomodoro');
const Task = require('../models/Task');
const auth = require('../middleware/auth');

// @route   GET api/statistics
// @desc    获取用户所有统计数据
// @access  Private
router.get('/', auth, async (req, res) => {
  try {
    const statistics = await Statistic.find({ userId: req.user.id }).sort({ date: -1 });
    res.json(statistics);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('服务器错误');
  }
});

// @route   GET api/statistics/daily/:date
// @desc    获取指定日期的统计数据
// @access  Private
router.get('/daily/:date', auth, async (req, res) => {
  try {
    const date = new Date(req.params.date);
    date.setHours(0, 0, 0, 0);
    
    const nextDate = new Date(date);
    nextDate.setDate(date.getDate() + 1);

    // 查找该日期的统计数据
    let statistic = await Statistic.findOne({
      userId: req.user.id,
      date: {
        $gte: date,
        $lt: nextDate
      }
    });

    // 如果不存在，则生成该日期的统计数据
    if (!statistic) {
      // 获取该日期的番茄钟记录
      const pomodoros = await Pomodoro.find({
        userId: req.user.id,
        startTime: {
          $gte: date,
          $lt: nextDate
        }
      });

      // 获取该日期的任务
      const tasks = await Task.find({
        userId: req.user.id,
        $or: [
          { createdAt: { $gte: date, $lt: nextDate } },
          { completedAt: { $gte: date, $lt: nextDate } }
        ]
      });

      // 计算统计数据
      const completedTasks = tasks.filter(task => task.completed && task.completedAt >= date && task.completedAt < nextDate).length;
      const totalTasks = tasks.length;
      
      const workPomodoros = pomodoros.filter(p => p.type === 'work' && p.completed && !p.interrupted);
      const completedPomodoros = workPomodoros.length;
      
      const totalWorkTime = workPomodoros.reduce((total, p) => total + p.duration, 0);
      
      // 按类别统计时间
      const categories = {};
      workPomodoros.forEach(p => {
        if (p.taskId) {
          const task = tasks.find(t => t._id.toString() === p.taskId.toString());
          if (task) {
            const category = task.category || '默认';
            if (!categories[category]) {
              categories[category] = 0;
            }
            categories[category] += p.duration;
          }
        }
      });

      const categoryArray = Object.keys(categories).map(name => ({
        name,
        timeSpent: categories[name]
      }));

      // 计算生产力得分 (简单算法: 完成任务比例 * 50 + 番茄钟完成数 * 10)
      const taskScore = totalTasks > 0 ? (completedTasks / totalTasks) * 50 : 0;
      const pomodoroScore = completedPomodoros * 10;
      const productivityScore = Math.min(100, taskScore + pomodoroScore);

      // 创建新的统计记录
      statistic = new Statistic({
        userId: req.user.id,
        date,
        completedTasks,
        totalTasks,
        completedPomodoros,
        totalWorkTime,
        productivityScore,
        categories: categoryArray
      });

      await statistic.save();
    }

    res.json(statistic);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('服务器错误');
  }
});

// @route   GET api/statistics/weekly/:startDate
// @desc    获取指定周的统计数据
// @access  Private
router.get('/weekly/:startDate', auth, async (req, res) => {
  try {
    const startDate = new Date(req.params.startDate);
    startDate.setHours(0, 0, 0, 0);
    
    const endDate = new Date(startDate);
    endDate.setDate(startDate.getDate() + 7);

    // 获取该周的每日统计数据
    const weeklyStats = await Statistic.find({
      userId: req.user.id,
      date: {
        $gte: startDate,
        $lt: endDate
      }
    }).sort({ date: 1 });

    // 如果某天没有数据，则生成该天的统计数据
    const days = [];
    for (let i = 0; i < 7; i++) {
      const currentDate = new Date(startDate);
      currentDate.setDate(startDate.getDate() + i);
      
      const dayStats = weeklyStats.find(stat => {
        const statDate = new Date(stat.date);
        return statDate.getDate() === currentDate.getDate() &&
               statDate.getMonth() === currentDate.getMonth() &&
               statDate.getFullYear() === currentDate.getFullYear();
      });

      if (dayStats) {
        days.push(dayStats);
      } else {
        // 获取该日期的统计数据（调用daily接口）
        const response = await fetch(`${req.protocol}://${req.get('host')}/api/statistics/daily/${currentDate.toISOString()}`);
        const dailyStats = await response.json();
        days.push(dailyStats);
      }
    }

    // 计算周统计数据
    const weekSummary = {
      startDate,
      endDate,
      totalCompletedTasks: days.reduce((total, day) => total + day.completedTasks, 0),
      totalTasks: days.reduce((total, day) => total + day.totalTasks, 0),
      totalCompletedPomodoros: days.reduce((total, day) => total + day.completedPomodoros, 0),
      totalWorkTime: days.reduce((total, day) => total + day.totalWorkTime, 0),
      averageProductivityScore: days.reduce((total, day) => total + day.productivityScore, 0) / days.length,
      days
    };

    res.json(weekSummary);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('服务器错误');
  }
});

// @route   GET api/statistics/monthly/:year/:month
// @desc    获取指定月的统计数据
// @access  Private
router.get('/monthly/:year/:month', auth, async (req, res) => {
  try {
    const year = parseInt(req.params.year);
    const month = parseInt(req.params.month) - 1; // JavaScript月份从0开始
    
    const startDate = new Date(year, month, 1);
    const endDate = new Date(year, month + 1, 1);

    // 获取该月的统计数据
    const monthlyStats = await Statistic.find({
      userId: req.user.id,
      date: {
        $gte: startDate,
        $lt: endDate
      }
    }).sort({ date: 1 });

    // 计算月统计数据
    const monthSummary = {
      year,
      month: month + 1,
      totalCompletedTasks: monthlyStats.reduce((total, day) => total + day.completedTasks, 0),
      totalTasks: monthlyStats.reduce((total, day) => total + day.totalTasks, 0),
      totalCompletedPomodoros: monthlyStats.reduce((total, day) => total + day.completedPomodoros, 0),
      totalWorkTime: monthlyStats.reduce((total, day) => total + day.totalWorkTime, 0),
      averageProductivityScore: monthlyStats.length > 0 ? 
        monthlyStats.reduce((total, day) => total + day.productivityScore, 0) / monthlyStats.length : 0,
      days: monthlyStats
    };

    res.json(monthSummary);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('服务器错误');
  }
});

// @route   GET api/statistics/categories
// @desc    获取用户所有类别的时间统计
// @access  Private
router.get('/categories', auth, async (req, res) => {
  try {
    const statistics = await Statistic.find({ userId: req.user.id });
    
    // 合并所有类别的时间统计
    const categories = {};
    statistics.forEach(stat => {
      stat.categories.forEach(cat => {
        if (!categories[cat.name]) {
          categories[cat.name] = 0;
        }
        categories[cat.name] += cat.timeSpent;
      });
    });

    const categoryArray = Object.keys(categories).map(name => ({
      name,
      timeSpent: categories[name]
    })).sort((a, b) => b.timeSpent - a.timeSpent);

    res.json(categoryArray);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('服务器错误');
  }
});

module.exports = router;
